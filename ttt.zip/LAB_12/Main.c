#include "TicTacToe.h"

int main(void) {

	Game_info today = { 0,0,0 };

	Board game = { {false, NONE, {0,0}} };

	init_board(&game);
	print_board(&game);

	Cell newcell = { true, X, {2,2} };
	update_board(&game, newcell);
	print_board(&game);

	return 1;
}