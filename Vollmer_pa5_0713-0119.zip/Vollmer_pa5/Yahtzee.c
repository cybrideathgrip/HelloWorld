/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#include "Yahtzee.h"

int game_loop(void){
	int continue_loop = 1; //game loop controller. game_loop only lasts up to 3 rolls. more like, 
	int roll_count = 0;
	int* hand_arr[HAND_SIZE];
	int* held_hand[HAND_SIZE] = { 0, 0, 0, 0, 0};

	press_continue();
	roll_hand(&hand_arr, HAND_SIZE);
	++roll_count;
	draw_hand(&hand_arr, HAND_SIZE);
	save_hand(&hand_arr, HAND_SIZE, &held_hand);
	printf("Held has: [");
	for (int i = 0; i < HAND_SIZE; i++)
	{
		printf("%d, ", held_hand[i]);
	}
	

} //main game loop. Will end when a player has won, return 1 for player 1, 2 for player 2. 

int roll_die(void){
	return rand() % 6 + 1;
} //return the roll of 1 die. what it goes into is not it's job.

//function puts the result of die roll into each element of the 'hand' array (size 5, 5 dice in a hand)
void roll_hand(int* hand[], int hand_size) {
	for (int i = 0; i < hand_size; i++)
	{
		hand[i] = roll_die();
	}
}

void draw_hand(int* hand[], int hand_size) {
	for (int i = 0; i < HAND_SIZE; i++)
	{
		printf("(%d)\n", i + 1);
		draw_roll(hand[i]);
	}
	printf("You Rolled: ");
	for (int i = 0; i < HAND_SIZE; i++)
	{
		printf("%d,", hand[i]);
	}
	press_continue();
}

int save_hand(int* hand[], int hand_size, int* held[]) {
	char save = '\0';
	printf("save some of your hand? (y/n) : ");
	scanf("%c", &save);
	
	if (save == 'n' || save == 'N')
	{
		printf("re-rolling all the die.\n");
		return 0;
	} else
	{
		printf("Input the dice you'd like to keep. input each number, seperated by a space, and ending your selection with a 0: ");
		for (int i = 0; i < 5; i++)
		{
			int num;
			char term;
			scanf("%d%c", &num, &term);
			if (num != 0 && term != '\n') {
				//the held[] array creates a "mask". To determine if a specific index of hand[] is re-rollled, the same index of held[] is 0.
			}
			else
				break;
		}
	}
}

int check_points(int* hand[], int size){

} // when it's time to check rolls, I want this function to call all the other check or validate functions...maybe.

int validate_sum_of_Ns(int* hand[], int size) {
	//might want to break this out
}

int validate_Full_House(int* hand[], int size){


}
int validate_3_kind(int* hand[], int size){

}
int validate_4_kind(int* hand[], int size){

}

int validate_small_straight(int* hand[], int size){

}
int validate_large_straight(int* hand[], int size){

}
int validate_yahtzee(int* hand[], int size){

}
int validate_chance(int* hand[], int size){

}

void press_continue(void) {
	printf("\nPress ENTER to continue.");
	getchar();
	getchar();
}

//function to draw a nice splash screen, to begin and end the game.
void draw_splash_screen(void) {
	draw_title_art();
	draw_dice_art(); 
	printf("\n\nPress Enter key\n");
	fflush(stdin);
	getchar();	//this getchar() is inteded to pause the program, and it works. The program pauses here. When the splash screen is drawn. But in the other functions it only pauses *after* the first getchar().
				//There must be something in the stream, hence the preceeding fflush(stin) to clearing the stream (no go). but it only works the first time here in this function, and not the gameplay loop, or the print rules function.
	system("cls");
}


void print_game_rules(void) {
	system("cls");
	printf("\nThe Rules of Yahtzee:\n");
	printf("The scorecard used for Yahtzee is composed of two sections: an upper, and a lower section. \n");
	printf("A total of thirteen boxes, or  \"scoring combinations\" are divided amongst the sections. \n"); 
	printf("The upper secion consists of boxes that are scored by summing the value of the dice matching the faces of the box. \n"); 
	printf("If a player rolls four 3's, then the score placed in the 3's box is the sum of the dice which is 12. \n"); 
	printf("Once a box is scored, it may not be changed and the combination is no longer in play for future rounds.\n"); 
	printf("If the sum of the scores in the upper section is greater than or equal to 63, the player earns a bonus 35 points. \n"); 
	printf("The lower section contains a number of poker like combinations. See the table provided below:\n");
	//print score table
	//fflush(stdin);
	press_continue();
}

//function to draw a neat picture to go with the logo
void draw_dice_art(void) {
	printf("  .-------.   ______     .-------.   ______       .-------. \n");
	printf(" /   o   /|  /\\     \\   /   o   /|  /\\     \\     /   o   /| \n");
	printf("/_______/o| /o \\  o  \\ /_______/o| /o \\  o  \\   /_______/o| \n");
	printf("| o     | |/   o\\_____\\| o     | |/   o\\_____\\ | o     |  | \n");
	printf("|   o   |o/\\o   /o    /|   o   |o/\\o   /o    / |   o   |o / \n");
	printf("|     o |/  \\ o/  o  / |     o |/  \\ o/  o  /  |     o | /  \n");
	printf("'-------'    \\/____o/  '-------'    \\/____o/   '-------'/   \n");
}

//function to draw a neat logo to go with the picture
void draw_title_art(void) {
	printf("  ___    ___ ________  ___  ___  _________  ________  _______   _______      \n");
	printf(" |\\  \\  /  /|\\   __  \\|\\  \\|\\  \\|\\___   ___\\\\_____  \\|\\  ___ \\ |\\  ___ \\     \n");
	printf(" \\ \\  \\/  / | \\  \\|\\  \\ \\  \\\\\\  \\|___ \\  \\_|\\|___/  /\\ \\   __/|\\ \\   __/|    \n");
	printf("  \\ \\    / / \\ \\   __  \\ \\   __  \\   \\ \\  \\     /  / /\\ \\  \\_|/_\\ \\  \\_|/__  \n");
	printf("   \\/   / /   \\ \\  \\ \\  \\ \\  \\ \\  \\   \\ \\  \\   /  /_/__\\ \\  \\_|\\ \\ \\  \\_|\\ \\ \n");
	printf(" __/   / /     \\ \\__\\ \\__\\ \\__\\ \\__\\   \\ \\__\\ |\\________\\ \\_______\\ \\_______\\\n");
	printf("|\\____/ /       \\|__|\\|__|\\|__|\\|__|    \\|__|  \\|_______|\\|_______|\\|_______|\n");
	printf("\\|____|/                                                                     \n");
}



void draw_roll(int number) {
	if (number == 1) {
		printf("+-------+\n");
		printf("|       |\n");
		printf("|   *   |\n");
		printf("|       |\n");
		printf("+-------+\n");
	}
	else if (number == 2) {
		printf("+-------+\n");
		printf("|     * |\n");
		printf("|       |\n");
		printf("| *     |\n");
		printf("+-------+\n");
	}
	else if (number == 3) {
		printf("+-------+\n");
		printf("|     * |\n");
		printf("|   *   |\n");
		printf("| *     |\n");
		printf("+-------+\n");
	}
	else if (number == 4) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("|       |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
	else if (number == 5) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("|   *   |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
	else if (number == 6) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("| *   * |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
}