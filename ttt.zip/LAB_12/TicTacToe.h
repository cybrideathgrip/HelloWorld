#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdbool.h>

#define ROWS 3
#define COLUMNS 3

//typedef struct player
//{
//	int wins;
//	int losses;
//	char symbol;
//}Player;

//may not use. NULL was broken.
typedef enum symbol
{
	NONE = 0, X = 1, O = 2,
}symbol;

typedef struct coordinate
{
	int row;
	int col;

}Coordinate;

typedef struct cell
{
	bool occupied;
	symbol mark;
	Coordinate location;
}Cell;

typedef struct board
{
	Cell game_board[ROWS][COLUMNS];
	/*int size_rows;
	int size_cols;*/
}Board;

typedef struct game_info 
{ 
	int player_wins; 
	int cpu_wins; 
	int total_games_played;
} Game_info;

void init_board(Board* game_board);
void print_board(Board* game_board);
void update_board(Board* game_board, const Cell cell);