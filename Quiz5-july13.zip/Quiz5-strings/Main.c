
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <ctype.h>

int count_alphas(char test[], int size);
int largest_sum_sequence(int sequence[], int size, int* index);

int main(void) {
	//count the number of alphabetical chars in a string.using count_alphas()

	char test_array[9] = "CpTs_121";
	printf("The string: %s has %d alphabetical characters.\n", test_array, count_alphas(test_array, 9));

	int test_sequence[5] = { -4, -3, -2, 11, -1 };
	int* max_index = 0;
	int* min_index = 0;
	int c = 0;


	printf("the largest sequence sum is: %d\n", largest_sum_sequence(test_sequence, 5, &max_index, &min_index));
	printf("min_index: %d, max_index %d\n", min_index, max_index);
	printf("from the sequence: [");

	if ((*max_index - *min_index) == 1) {
		printf("%d]\n", test_sequence[*max_index]);
	}
	else if ((max_index - min_index) < 0)
	{
		for (int i = (min_index ); i <= max_index; i++)
		{
			printf("%d ", test_sequence[i]);
		}
		printf("]\n");
	}
	else if ((max_index - min_index) > 0) {
		for (int i = 0; i <= max_index; i++)
		{
			printf("%d ", test_sequence[i]);
		}
		printf("]\n");
	}
	
	return 0;
}

int count_alphas(char test[], int size) {

	int alpha_count = 0;
	for (int i = 0; i < size; i++)
	{
		if (isalpha(test[i])) {
			++alpha_count;
		}
	}
	return alpha_count;
}

int largest_sum_sequence(int sequence[], int size, int* max_index, int* min_index) {

	int sum_arr[5];
	int sum = 0,  cur_max = 0;
	

	for (int i = 0; i < size; i++)
	{
		sum += sequence[i];
		sum_arr[i] = sum;
		if (sum_arr[i] > cur_max)
		{
			cur_max = sum_arr[i];
			*max_index = i;
		}
		else if (sum_arr[i] < 0) 
		{
			sum_arr[i] = 0;
			sum = 0;
			*min_index = i;
		}
	}
	
	return cur_max;
}