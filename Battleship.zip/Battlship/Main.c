/*
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date: 7/16/2020

Description: Writing a game of battleship! To be played human vs computer.
			Placing 5 boats of mostly different size on a 10x10 grid and taking turns "firing" on a coordiate to determine hit or miss once per turn.
			The victor will hit all spaces of their opponents battleships before all thier own are hit.

Background:	we'll be using a lot of strings, arrays, introducing struts, and a 'computer controlled player' for the first time.

Relevant Formulas: 
*/
#include "Battleship.h"

int main(void) {
	srand(time(NULL));
	welcome_screen();
	initialize_game_board();
	

	return 1;
}
