/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#include "Poker.h"

/* shuffle cards in deck */

void shuffle(int wDeck[][13])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* for each of the 52 cards, choose slot of deck randomly */
	for (card = 1; card <= 52; card++)
	{
		/* choose new random location until unoccupied slot found */
		do
		{
			row = rand() % 4;
			column = rand() % 13;
		} while (wDeck[row][column] != 0);

		/* place card number in chosen slot of deck */
		wDeck[row][column] = card;
	}
}

/* deal cards in deck */
void deal(const int wDeck[][13], const char* wFace[], const char* wSuit[])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* deal each of the 52 cards */
	for (card = 1; card <= 52; card++)
	{
		/* loop through rows of wDeck */
		for (row = 0; row <= 3; row++)
		{
			/* loop through columns of wDeck for current row */
			for (column = 0; column <= 12; column++)
			{
				/* if slot contains current card, display card */
				if (wDeck[row][column] == card)
				{
					printf("%5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
				}
			}
		}
	}
}





void press_continue(void) 
{
	printf("\n");
	system("pause");
}

void welcome_screen(void) 
{
	draw_title_art();
	draw_hand_art();
	press_continue(); 
	system("cls");
}

void draw_title_art(void) 
{
	
	printf("    .------..------..------..------..------. \n");
	printf("    |P.--. ||O.--. ||K.--. ||E.--. ||R.--. | \n");
	printf("    | :/\\: || :/\\: || :/\\: || (\\/) || :(): | \n");
	printf("    | (__) || :\\/: || :\\/: || :\\/: || ()() | \n");
	printf("    | '--'P|| '--'O|| '--'K|| '--'E|| '--'R| \n");
	printf("    `------'`------'`------'`------'`------' \n");
}

void draw_card_art(void) 
{
	printf("               _____                      \n");
	printf("              |A .  | _____               \n");
	printf("              | /.\ ||A ^  | _____        \n");
	printf("              |(_._)|| / \\ ||A _  | _____ \n");
	printf("              |  |  || \\ / || ( ) ||A_ _ |\n");
	printf("              |____V||  .  ||(_'_)||( v )|\n");
	printf("                     |____V||  |  || \\ / |\n");
	printf("                            |____V||  .  |\n");
	printf("                                   |____V|\n");
}

void draw_hand_art(void)
{
	printf("                  __                   \n\n");
	printf("             _..-''--'----_.           \n");
	printf("           ,''.-''| .---/ _`-._        \n");
	printf("         ,' \\ \\  ;| | ,/ / `-._`-.   \n");
	printf("       ,' ,',\ \( | |// /,-._  / /     \n");
	printf("       ;.`. `,\ \`| |/ / |   )/ /      \n");
	printf("      / /`_`.\_\\ \| /_.-.'-''/ /      \n");
	printf("     / /_|_:.`. \\ |;'`..')  / /       \n");
	printf("     `-._`-._`.`.;`.\  ,'  / /         \n");
	printf("         `-._`.`/    ,'-._/ /          \n");
	printf("           : `-/     \`-.._/           \n");
	printf("           |  :      ;._ (             \n");
	printf("           :  |      \\  ` \\          \n");
	printf("            \\         \\   |          \n");
	printf("             :        :   ;            \n");
	printf("             |           /             \n");
	printf("             ;         ,'              \n");
	printf("            /         /                \n");
	printf("           /         /                 \n");
	printf("                    /                  \n");
}

void print_game_rules(void) 
{
	
	system("cls");
	printf("\nThe Rules of Poker:\n");
	printf("Poker is a betting game played with cards.\n");
	printf("There are many variations in poker games, this one is called: 5-card draw.");
	printf("Every player is dealt a hand of 5 cards. \nAfter the deal a player may choose to re-draw any number of cards from the deck.\n");
	printf("The goal is to have the best hand of 5 cards among all the players.\n");
	printf("There are 10 possible combinations of cards in poker, each ranked in a specific hierarchy.\n\n");
	printf("That ranking is:\n----------------\n");
	printf("\n 1 - Royal Flush\n 2 - Straight Flush\n 3 - Four of a Kind\n 4 - Full House\n 5 - Flush\n");
	printf(" 6 - Straight\n 7 - Three of a kind\n 8 - Two Pair\n 9 - Pair\n10 - High Card\n\n");
	//would be nice to make this list a menu, that will display detail about each hand.
	printf("There are 3 round of betting that occur with every Hand.\n");
	printf("An initial bet, alled an 'ante' must be made to be dealt into a hand.\n");
	printf("After the first hand of 5 cards are dealt, and redrawn, there is a final round of betting to up the ante, or call a \nbluff.");
	printf("At any point after the deal, you may choose to fold. Avoiding obligation for additonal betting, while also forfeiting any potential winnings.\n");
	printf("You are NOT obligated to reveal your hand on a fold.\n");

	press_continue();
	system("cls");
}