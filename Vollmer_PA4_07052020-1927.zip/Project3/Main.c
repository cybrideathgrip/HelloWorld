/*
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 4:  A Game of Chance "Craps"

Date: 6/30/2020

Description: This program is 
Background: This Program will utilize a 3-file format for a C program, which is designed to include:
            - Conditional statements.
            - Loops
            - logical expressions.
            - Custom defined functions.
            - I might throw in a pointer, it could help.
            A modicum of statistical math is required for some of these equations. Most of which are provided4


Relevant Formulas: Not much more than simple addition and subtraction for this one.
                   Add money to bank.
                   add or subtract a wager amount
                   roll and add dice. 
*/

#include "PA4_Header.h"

int main(void) {

    //seed the random number generator for later use.
    srand(time);

    //this block begins our game with a nice title splash screen
    //I'm going to do it again at the end of the program, so I made it into a function.
    
    printf("\nWelcome! To the Game of \n");
    draw_splash_screen();
    
    //Mian menu has to be a loop, so we get back to it.
    //but I also want it to be a switch, so we know where to go from our menu. 
    //switch returns a 1, 2 or 3; determining what gets called next. Rules, play or exit respectively.
   
    int main_menu = 0;
   //outer do-while loop is our main-menu. From here we can start the game, and continue play unill we chose to exit
   do {
       //inner do-while loop checks or valid menu input.
       do {
           printf("\n\nMain Menu.\n\n");
           printf("Please Choose an entry using the corresponding number.\n");
           printf("1) Read Rules of playing Craps\n");
           printf("2) Start a good ol' fashioned game of CRAPS!\n");
           printf("3) quit program.\nAn invalid choice will just reprint this menu.\n\n");
           scanf("%d", &main_menu);
       } while (!(main_menu == 1 || main_menu == 2 || main_menu == 3));

       switch (main_menu) {
       case 1:
           print_game_rules();
           break;
       case 2:
           main_menu = game_loop();
           break;
       case 3:
           printf("Thank you for playing a game of \n");
           draw_splash_screen();
           break;
       }
    }while (main_menu != 3);

    printf("\nThank you so much for playing a Game of \n");
    draw_splash_screen();

    return 0;
}