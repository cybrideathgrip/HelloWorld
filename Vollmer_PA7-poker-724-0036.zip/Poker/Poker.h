/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//shuffle cards in the deck
void shuffle(int wDeck[][13]);

//deal a hand of cards from the deck.
void deal(const int wDeck[][13], const char* wFace[], const char* wSuit[]);

//pretty graphcis. Reminiscent of Craps, Yahtzee and Battleship
void welcome_screen(void);
void draw_title_art(void);
void draw_card_art(void);
void print_game_rules(void);
void press_continue(void);
void draw_hand_art(void);

//struct declaration

typedef struct card
{
	int face;
	int suit;
}Card;

typedef struct hand
{
	Card hand[];
};


