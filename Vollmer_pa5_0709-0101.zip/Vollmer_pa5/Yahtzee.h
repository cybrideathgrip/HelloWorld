/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

void draw_splash_screen(void);

void print_game_rules(void);

void draw_dice_art(void);

void draw_title_art(void);

void draw_splash_screen(void);

void press_continue(void);
