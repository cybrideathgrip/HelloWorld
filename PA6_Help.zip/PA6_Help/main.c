
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <time.h>
#include <stdbool.h>

#define FLEET_SIZE 5

void init_board(char board[][10], int rows, int cols);
void print_board(char board[][10], int rows, int cols);
void place_boat(char board[][10], struct boat ship);
char boat_orientation(char horiz);
void get_coords(int* x, int* y);
//void update_opponent_fleet(char result, Boat* fleet[], int player_points);
void display_fleet(struct boat floatilla);

typedef struct boat {
	char name[11];
	char symbol;
	int x_coord;
	int y_coord;
	int size;
	int hits;
	bool sunk;
}Boat;

int main(void)
{
	Boat fleet1[FLEET_SIZE] = { { "Carrier"   , 'C', 0, 0, 5, 0, false},
								{ "Battleship", 'B', 0, 0, 4, 0, false},
								{ "Cruiser"   , 'R', 0, 0, 3, 0, false},
								{ "Submarine" , 'S', 0, 0, 3, 0, false},
								{ "Destroyer" , 'D', 0, 0, 2, 0, false} };

	Boat fleet2[FLEET_SIZE] = { { "Carrier"   , 'C', 0, 0, 5, 0, false},
								{ "Battleship", 'B', 0, 0, 4, 0, false},
								{ "Cruiser"   , 'R', 0, 0, 3, 0, false},
								{ "Submarine" , 'S', 0, 0, 3, 0, false},
								{ "Destroyer" , 'D', 0, 0, 2, 0, false} };

	
	for (int i = 0; i < FLEET_SIZE; i++)
	{
		printf("by itself: %c\n", fleet1[i].symbol);
	}

	Boat *ptr_arr = &fleet1;
	for (int i = 0; i < 5; i++)
	{	
		printf("pointed: %d\n", (ptr_arr+i)->size);
	}

	//display_fleet(ptr_arr);

	//char p1_board[10][10] = { {'\0'} };

	//init_board(p1_board, 10, 10);
	////print_board(p1_board, 10, 10);
	//
	//Boat boat1 = { "Submarine", 'U', 0, 0, 3, 0 };

	//printf("name: %s, symbol %c, Xcoord: %d, ycoord: %d, size: %d, hits: %d\n", boat1.name, boat1.symbol, boat1.x_coord, boat1.y_coord, boat1.size, boat1.hits);

	//int x, y;
	//get_coords(&x, &y);
	//printf("main now has: %d, %d\n", x, y);

	//boat1.x_coord = x;
	//boat1.y_coord = y;
	//
	//printf("name: %s, symbol %c, Xcoord: %d, ycoord: %d, size: %d, hits: %d\n", boat1.name, boat1.symbol, boat1.x_coord, boat1.y_coord, boat1.size, boat1.hits);
	////Boat boat2 = { "Carrier", 'C', x, y, 5, 0 };

	//place_boat(p1_board, boat1);
	//print_board(p1_board, 10, 10);

	////time_t timer = time(NULL);
	////printf("current time is %s ", ctime(&timer));
	////printf("day: %d, month: %d, year, %d", 

	return 0;
}

void display_fleet(struct boat floatilla){
	char test = 'C';
	//printf("component fleet1[2].symbol: %c\n", *collection[0].symbol);
	for (int i = 0; i < FLEET_SIZE; i++)
	{
		printf("by itself: %c\n", (floatilla + i)->symbol);
		//printf("name %d: %s\n", i, *collection[i].name);
	}

}

//void update_opponent_fleet(char result, Boat* fleet[], int player_points) {
//	int target_index = NULL;
//	for (int i = 0; i < FLEET_SIZE; i++)
//	{
//
//		if ((*fleet[i])->symbol == result) {
//			target_index = i;
//			fleet[i].hits += 1;
//			printf("fleet updated.\n");
//		}
//	}
//	if (check_if_sunk_ship(fleet[target_index])) {
//		player_points += 1;
//		printf("AND SUNK!\N");
//	}
//}

void get_coords(int* x, int* y) {
	char a;
	int b, n;
	printf("input coordinate: ");
	scanf("%c %d", &a, &b);
	//n = (int)a - 65;
	printf("picked up: %d, %d\n", (int)a, b);
	//passn it back:
	*x = (int)a - 65;
	*y = b -1;
}

void place_boat(char board[][10], struct boat ship) {
	char horiz = NULL;
	//printf("where do you want your boat? (ex: A2)");
	//scanf("%c %d", &ship.x_coord, &ship.y_coord);

	horiz = boat_orientation(horiz);
	switch (horiz) {
	case '|':
		for (int i = 0; i < ship.size; i++)
		{
			board[ship.y_coord + i][ship.x_coord] = ship.symbol;
		}
		break;
	case '-':
		for (int i = 0; i < ship.size; i++)
		{
			board[ship.y_coord][ship.x_coord + i] = ship.symbol;
		}
		break;
	}
}

char boat_orientation(char horiz) {
	do
	{
		printf("Vertical (|) or Horizontal? (-) ");
		scanf("%c", &horiz);
	} while(!(horiz == '|' || horiz == '-'));
	return horiz;
}

void init_board(char board[][10], int rows, int cols){
	for (int row_index = 0; row_index < rows; ++row_index)
	{
		for (int col_index = 0; col_index < cols; ++col_index)
		{
			int a = 175;
			board[row_index][col_index] = a;
		}
	}
}

void update_board(char board[][10], char x, char y, char u) {
	board[y][x] = u;
}

void print_board(char board[][10], int rows, int cols)
{	
	printf("   ");
	for (int col_index = 0; col_index < cols;
		++col_index)
	{
		printf("%c ", col_index + 65);
	}
	printf("\n");
	for (int row_index = 0; row_index < rows; ++row_index)
	{
		printf("%2d ", row_index + 1);
		for (int col_index = 0; col_index < cols;
			++col_index)
		{
			printf("%c ", board[row_index][col_index]);
		}
		putchar('\n');
	}
}