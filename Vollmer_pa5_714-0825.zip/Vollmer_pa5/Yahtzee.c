/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#include "Yahtzee.h"

int game_loop(void){
	int continue_loop = 1; //game loop control variable. Used in between main menu visits.
	int point_rack[14];
	//int point_rack_p2[13]; -- must be differentiated btwn p1 and p2, but be the "same" for the game loop.
	int p1_points[13];
	int p2_points[13]; //point rack is now acting a temp in player loop. Assigned to p1 or 2 on entrance and exit or player loop.
	//definng point rack indecies as laid out in the assignment. 
	//1 - 6 sum of n's 1-6. 7-12 for the "lower box". and 13 for 'chance'
	//the corresponding index is populated and won't be reset untill the end of game, those points have been counted.

		//Player loop below here. only lasts up to 3 rolls. changes **Player**
		int player_count = 1; //if player count is odd, it's player 1. If Even, player 2.
		int roll_count = 0;
		bool save_pts = false;
		int* hand_arr[HAND_SIZE];
		bool* hold_arr[] = {0, 0, 0, 0, 0};
		int hold_index;

		printf("May the odds be ever in your favor...\n");
		press_continue();
		do
		{
			roll_hand(&hand_arr, HAND_SIZE, &hold_arr);
			++roll_count;
			printf("Roll: %d! \n", roll_count);
			draw_hand(&hand_arr, HAND_SIZE); //display hand of dice only

			if (save_hand() == false && roll_count < 3)
			{
				update_hold(&hold_arr);
			}
		} while (roll_count < 3 && save_pts == false);
		
		//print_point_menu();
		save_points(&hand_arr, HAND_SIZE, &point_rack); //update score card.
		//player loop ends here.
		//roll loop resets values for next player, and starts again.
		reset_hold(&hold_arr, HAND_SIZE);
		++player_count;
		
} //main game loop. Will end when a player has won, return 1 for player 1, 2 for player 2. 

int roll_die(void){
	return rand() % 6 + 1;
} //return the roll of 1 die. what it goes into is not it's job.

//function puts the result of die roll into each element of the 'hand' array (size 5, 5 dice in a hand)
void roll_hand(int* hand[], int hand_size, bool* holds[]) {
	for (int i = 0; i < hand_size; i++)
	{
		if (holds[i] == false) 
		{
			hand[i] = roll_die();
		}
	}
}

void draw_hand(int* hand[], int hand_size) {
	for (int i = 0; i < HAND_SIZE; i++)
	{
		printf("(%d)\n", i + 1);
		draw_roll(hand[i]);
	}
	printf("You Rolled: ");
	for (int i = 0; i < HAND_SIZE; i++)
	{
		printf("%d,", hand[i]);
	}
	press_continue();
}

bool save_hand() {
	char save = '\0';
	printf("Bank points for this hand and end your turn? (y/n) : ");
	scanf("%c", &save);
	if (save == 'n' || save == 'N')
	{
		printf("Keep on rolling.\n");
		return false;
	}
	else
	{
		return true;
	}
}
void reset_hold(bool* hold[], int size) {
	for (int i = 0; i < size; i++)
	{
		hold[i] = false;
	}
}
void update_hold(bool* hold[]) {
	int index;
	do
	{
		printf("Please choose a die to hold onto. (input a 0 to continue) ");
		scanf("%d", &index);
		
		if (hold[index - 1] == 0) {
			printf("holding dice %d \n");
			hold[index - 1] == true;
		}
		else
			printf("removing hold on die %d \n");
			hold[index - 1] = false;
		/* what last worked inside this while loop:
		if(index != 0){
			hold[index - 1] = true (or 1, idk)
			}and that's it.
		*/
	} while (index != 0);
}

int save_points(int* hand[], int size, int point_rack_) {
	int point_pick;
	print_point_menu();
	printf("input selection here: ");
	scanf("%d", &point_pick);

	switch (point_pick)
	{
	case 1:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 1);
		break;
	case 2:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 2);
		break;
	case 3:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 3);
		break;
	case 4:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 4);
		break;
	case 5:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 5);
		break;
	case 6:
		return validate_sum_of_Ns(&hand, HAND_SIZE, 6);
		break;
	case 7:
		return validate_3_kind(&hand, HAND_SIZE);
		break;
	case 8:
		return validate_4_kind(&hand, HAND_SIZE);
		break;
	case 9:
		return validate_Full_House(&hand, HAND_SIZE);
		break;
	case 10:
		return validate_small_straight(&hand, HAND_SIZE);
		break;
	case 11:
		return validate_large_straight(&hand, HAND_SIZE);
		break;
	case 12: 
		return validate_yahtzee(&hand, HAND_SIZE);
		break;
	case 0:
		break;
	default:
		printf("Invalid entry. Try again.\n");
	}
}

int check_points(int* hand[], int size){

} // when it's time to check rolls, I want this function to call all the other check or validate functions...maybe.

int validate_sum_of_Ns(int* hand[], int size, int N) {
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++)
	{
		if (hand[i] == N) {
			freq_arr[N] += 1;
		}
	}
	return freq_arr[N];
}

int validate_Full_House(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}

}
int validate_3_kind(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}
int validate_4_kind(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}

int validate_small_straight(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}
int validate_large_straight(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}
int validate_yahtzee(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}
int validate_chance(int* hand[], int size){
	int freq_arr[6] = { 0,0,0,0,0,0 };
	for (int i = 0; i < size; i++) {}
}

void press_continue(void) {
	printf("\nPress ENTER once or twice to continue.");
	getchar();
	getchar();
}

//function to draw a nice splash screen, to begin and end the game.
void draw_splash_screen(void) {
	draw_title_art();
	draw_dice_art(); 
	printf("\n\nPress Enter key\n");
	fflush(stdin);
	getchar();	//this getchar() is inteded to pause the program, and it works. The program pauses here. When the splash screen is drawn. But in the other functions it only pauses *after* the first getchar().
				//There must be something in the stream, hence the preceeding fflush(stin) to clearing the stream (no go). but it only works the first time here in this function, and not the gameplay loop, or the print rules function.
	system("cls");
}

void print_point_menu(void) {
	printf("Select your points!\n\n");
	printf("1. Sum of 1's \t 7. Three-of-a-kind\n");
	printf("2. Sum of 2's \t 8. Four-of-a-kind\n");
	printf("3. Sum of 3's \t 9. Full House\n");
	printf("4. Sum of 4's \t 10. Small Straight\n");
	printf("5. Sum of 5's \t 11. Large straight\n");
	printf("6. Sum of 6's \t 12. Yahtzee!");
	printf("\t 13. Chance \t");
	printf("(input 0 to quit)\n");
}

void print_game_rules(void) {
	system("cls");
	printf("\nThe Rules of Yahtzee:\n");
	printf("The scorecard used for Yahtzee is composed of two sections: an upper, and a lower section. \n");
	printf("A total of thirteen boxes, or  \"scoring combinations\" are divided amongst the sections. \n"); 
	printf("The upper secion consists of boxes that are scored by summing the value of the dice matching the faces of the box. \n"); 
	printf("If a player rolls four 3's, then the score placed in the 3's box is the sum of the dice which is 12. \n"); 
	printf("Once a box is scored, it may not be changed and the combination is no longer in play for future rounds.\n"); 
	printf("If the sum of the scores in the upper section is greater than or equal to 63, the player earns a bonus 35 points. \n"); 
	printf("The lower section contains a number of poker like combinations. See the table provided below:\n");
	//print score table
	//fflush(stdin);
	press_continue();
}

//function to draw a neat picture to go with the logo
void draw_dice_art(void) {
	printf("  .-------.   ______     .-------.   ______       .-------. \n");
	printf(" /   o   /|  /\\     \\   /   o   /|  /\\     \\     /   o   /| \n");
	printf("/_______/o| /o \\  o  \\ /_______/o| /o \\  o  \\   /_______/o| \n");
	printf("| o     | |/   o\\_____\\| o     | |/   o\\_____\\ | o     |  | \n");
	printf("|   o   |o/\\o   /o    /|   o   |o/\\o   /o    / |   o   |o / \n");
	printf("|     o |/  \\ o/  o  / |     o |/  \\ o/  o  /  |     o | /  \n");
	printf("'-------'    \\/____o/  '-------'    \\/____o/   '-------'/   \n");
}

//function to draw a neat logo to go with the picture
void draw_title_art(void) {
	printf("  ___    ___ ________  ___  ___  _________  ________  _______   _______      \n");
	printf(" |\\  \\  /  /|\\   __  \\|\\  \\|\\  \\|\\___   ___\\\\_____  \\|\\  ___ \\ |\\  ___ \\     \n");
	printf(" \\ \\  \\/  / | \\  \\|\\  \\ \\  \\\\\\  \\|___ \\  \\_|\\|___/  /\\ \\   __/|\\ \\   __/|    \n");
	printf("  \\ \\    / / \\ \\   __  \\ \\   __  \\   \\ \\  \\     /  / /\\ \\  \\_|/_\\ \\  \\_|/__  \n");
	printf("   \\/   / /   \\ \\  \\ \\  \\ \\  \\ \\  \\   \\ \\  \\   /  /_/__\\ \\  \\_|\\ \\ \\  \\_|\\ \\ \n");
	printf(" __/   / /     \\ \\__\\ \\__\\ \\__\\ \\__\\   \\ \\__\\ |\\________\\ \\_______\\ \\_______\\\n");
	printf("|\\____/ /       \\|__|\\|__|\\|__|\\|__|    \\|__|  \\|_______|\\|_______|\\|_______|\n");
	printf("\\|____|/                                                                     \n");
}



void draw_roll(int number) {
	if (number == 1) {
		printf("+-------+\n");
		printf("|       |\n");
		printf("|   *   |\n");
		printf("|       |\n");
		printf("+-------+\n");
	}
	else if (number == 2) {
		printf("+-------+\n");
		printf("|     * |\n");
		printf("|       |\n");
		printf("| *     |\n");
		printf("+-------+\n");
	}
	else if (number == 3) {
		printf("+-------+\n");
		printf("|     * |\n");
		printf("|   *   |\n");
		printf("| *     |\n");
		printf("+-------+\n");
	}
	else if (number == 4) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("|       |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
	else if (number == 5) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("|   *   |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
	else if (number == 6) {
		printf("+-------+\n");
		printf("| *   * |\n");
		printf("| *   * |\n");
		printf("| *   * |\n");
		printf("+-------+\n");
	}
}