#include "TicTacToe.h"



//may not use. NULL was broken.
//typedef enum symbol
//{
//	NONE = NULL , X = 1, O = 0,
//}symbol;

void init_board(Board* game_board) {

	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < COLUMNS; j++)
		{
			game_board->game_board[i][j].location.row = i;
			game_board->game_board[i][j].location.row = j;
			game_board->game_board[i][j].mark = NONE;
			game_board->game_board[i][j].occupied = false;
		}
	}

}

void print_board(Board* game_board) {
	printf("%4c", 32);
	for (int j = 0; j < COLUMNS; j++)
	{
		printf("%4d", j + 1);
	}
	//printf("\n");

	for (int i = 0; i < ROWS; i++)
	{
		printf("\n%3d ", i + 1);
		for (int j = 0; j < COLUMNS; j++)
		{
			switch (game_board->game_board[i][j].mark)
			{
			case NONE: printf("%3s", "   |");
				break;
			case X: printf("%3s", " X |");
				break;
			case O: printf("%3s", " O |");
				break;
			}
		}
	}
	printf("\n\n");
}

void update_cell()
{

}

void update_board(Board* game_board, const Cell cell)
{
	game_board->game_board[cell.location.row][cell.location.col].mark = cell.mark;
	game_board->game_board[cell.location.row][cell.location.col].occupied = cell.occupied;
}

