/*
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date: 7/16/2020

Description: Writing a game of battleship! To be played human vs computer.
			Placing 5 boats of mostly different size on a 10x10 grid and taking turns "firing" on a coordiate to determine hit or miss once per turn.
			The victor will hit all spaces of their opponents battleships before all thier own are hit.

Background:	we'll be using a lot of strings, arrays, introducing struts, and a 'computer controlled player' for the first time.

Relevant Formulas:
*/

#include "Battleship.h"

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//begin game loop
void game_loop(void) {
	//pre-player-initialization - board(s), ships, p1 p2.
	int player_count = NULL;
	int x = 0, y = 0;
	char horiz = NULL;
	char p1_board[GRID_SIZE][GRID_SIZE] = { {'\0'} };
	char p2_board[GRID_SIZE][GRID_SIZE] = { {'\0'} };
	char p1_target[GRID_SIZE][GRID_SIZE] = { {'\0'} };
	char p2_target[GRID_SIZE][GRID_SIZE] = { {'\0'} };
	int p1_points = 0, p2_points = 0;
	
	Boat fleet1[FLEET_SIZE] = { { "Carrier"   , 'C', 0, 0, 5, 0, false},
									   { "Battleship", 'B', 0, 0, 4, 0, false},
									   { "Cruiser"   , 'R', 0, 0, 3, 0, false},
									   { "Submarine" , 'S', 0, 0, 3, 0, false},
									   { "Destroyer" , 'D', 0, 0, 2, 0, false} };

	Boat fleet2[FLEET_SIZE] = { { "Carrier"   , 'C', 0, 0, 5, 0, false},
									   { "Battleship", 'B', 0, 0, 4, 0, false},
									   { "Cruiser"   , 'R', 0, 0, 3, 0, false},
									   { "Submarine" , 'S', 0, 0, 3, 0, false},
									   { "Destroyer" , 'D', 0, 0, 2, 0, false} };

	printf("component: ", fleet1[2].name);
	printf("component2: ", fleet1[3].symbol);
	//1) decide who goes first.
	player_count = select_who_starts_first();

	//2) initialze empty board(s). populates the arrays initialized above.
	initialize_game_board(p1_board, GRID_SIZE, GRID_SIZE);
	initialize_game_board(p2_board, GRID_SIZE, GRID_SIZE);
	initialize_game_board(p1_target, GRID_SIZE, GRID_SIZE);
	initialize_game_board(p2_target, GRID_SIZE, GRID_SIZE);

	//3) place all  5 ships P1 then P2...
		//foreach ship[n=5]:
			//draw board
			//place ship n
		//repeat
										 //============================================================|
	for (int i = 0; i < FLEET_SIZE; i++) //iterates placement loop for all boats in the player's fleet |
	{									 //============================================================|
		do {
			bool board_check = false;
			bool place_check = false;
			print_board(p1_board); //to reference what is currently in place.
			
			printf("Admiral, Place your %s! (%d spaces)\n", fleet1[i].name, fleet1[i].size);
			//recieve input from player. X, Y,and orientation.
			x = get_x_coord();
			y = get_y_coord();
			horiz = get_horizontal();
			//validates input. Checks to ensure placement is in-ocean. and not overlapping ships.
			board_check = validate_in_bounds(fleet1[i], x, y, horiz);
			place_check = validate_empty_space(p1_board, fleet1[i], x, y, horiz);
			if (place_check == true && board_check == true) {
				place_boat(p1_board, fleet1[i], x, y, horiz); //updates the p1_board if placement is valid.
				break;
			}else if (board_check == false)
			{
				system("cls");
				printf("Incorrect placement! \nOut of Bounds. \nTry again\n");
			}else if (place_check == false)
			{
				system("cls");
				printf("Incorrect placement! \nYou cannot overlap ships. \nTry again\n");
			}			////===========================================================================|
		} while (true); //proceeds to the next iteration of for loop after the ship placement is valid.|
		system("cls");  ////===========================================================================|
	}
	system("cls");
	print_board(p1_board);
	printf("The stage has been set in the theatre of war.\n");
	press_continue();
	system("cls");
	printf("opponent is mobilizing fleet...\n");

	for (int i = 0; i < FLEET_SIZE; i++)
	{
		randomly_place_ships_on_board(p2_board, fleet2[i]);
	}

	system("cls");
	print_board(p2_board);
	press_continue();
	system("cls");

	//=========================================================|
	//could call all that game_setup in it's own funciton..... |
	//=========================================================|


	//==================Start player turn Loop==================
	//4) begin play loop.
	// first determine which player. based on player count. if it's odd, p1, if even p2. the starting value is random 0 or 1.
	// Must track which is opponent or not.
	// switch? case 1: player turn, ask for inputs. populate outputs.
	//		   case 2: cpu player. use RNG's and populate values but not print. will have to draw player board and target board. 
	bool win = false;
	int curr_player = is_odd(player_count);
	int turn_counter = 0;
	int player[2] = { 2, 1 }; //rather hackney'd relation player 1 or 2 displaying for player tracking integer being even or odd....
	do {
		system("cls");
		//printf("BIG CAPITOL LETTERS starting turn. Switch will see: %d\n", curr_player);
		//printf("littel letters: player_count mod 2 = %d\n", player_count % 2);
		//system("pause");
		//curr_player = player_count % 2;
		switch (curr_player) 
		{
		case 1:
			//player = 1;
			system("cls");
			printf("!=====player %d Take your shot=====!\n", player[curr_player]);
			player_take_turn(p1_target, p2_board, &fleet2, p1_points);
			printf("player %d. score %d", player[curr_player], p1_points);
			//player_count += 1;
			break;
		case 0:
			//curr_player = 2;
			system("cls");
			printf("!=====player %d Take your shot=====!\n", player[curr_player]);
			cpu_take_turn(p2_target, p1_board, &fleet1, p2_points);
			printf("player %d. score %d", player[curr_player], p2_points);
			//++player_count;
			break;
		}
		++player_count;
		curr_player = player_count % 2;
		++turn_counter;
	} while (win == false);
	//end player loop. 

	return 0;
}
//end gameplay loop.
//=======================Start player turn Loop=====================
/*return player;*/
//}


void output_stats(void) {
	//writes stats from each player to log file
}

bool check_if_sunk_ship(Boat* ship){
	if ((*ship).hits == (*ship).size) {
		return true;
	}
	else return false;
}

void output_current_move(FILE* outfile ) {
	//writes shot posisition, also hit miss or sink result.

}

//after shot are taken "*" for hit and "m' for miss >.< I like X's and O's.
//must update a player ocean, and the opposite player's target ocean.
void update_board(char board[][GRID_SIZE], char x, char y, char u) {
	board[y][x] = u;
}

int is_winner() {
	//will have to accept player's list of boat structs. 
	//if all struct.boat.sunk = true for a player, the game ends, the opposite playeris the victor.
	//this check might have to be between every turn. or really after 17 shots, 34 turns. That's the minimum.

}

void update_opponent_fleet(char result, Boat* fleet[], int player_points) {
	int target_index = NULL;

	for (int i = 0; i < FLEET_SIZE; i++)
	{
		if ((*fleet + i)->symbol == result) {
			(*fleet + i)->hits += 1;
			target_index = i;
		}
	}

	if (check_if_sunk_ship(fleet[target_index])) {
		player_points += 1;
		(*fleet + target_index)->sunk == true;
		printf("...AND IT SUNK!!\n");
	}
}

int player_take_turn(char target_board[][GRID_SIZE], char opponent_board[][GRID_SIZE], Boat* opponent_fleet[FLEET_SIZE], int player_points) {
	char hit_result = '\0';
	int turn = 0;
	do
	{
		print_board(target_board);
		printf("Captain, input Attack Coordinates: \n");
		int tar_x = get_x_coord();
		int tar_y = get_y_coord();
		
		if (check_coord(target_board, tar_x, tar_y) == SEA_CHAR)
		{	
			hit_result = check_coord(opponent_board, tar_x, tar_y);
			if (hit_result == SEA_CHAR) {
				printf("That's a MISS...\n");
				update_board(target_board, tar_x, tar_y, MISS_CHAR);
				print_board(target_board);
				turn = 1;
			}
			else {
				printf("That's a HIT!\n");
				update_board(target_board, tar_x, tar_y, HIT_CHAR);
				print_board(target_board);
				update_opponent_fleet(hit_result, opponent_fleet, player_points);
				turn = 1;
			}
		}else printf("You already attacked that one. Try again.\n");
	} while (turn == 0);
	press_continue();
	return 1;
}

int cpu_take_turn(char target_board[][GRID_SIZE], char opponent_board[][GRID_SIZE], Boat* opponent_fleet[FLEET_SIZE], int player_points) {
	int turn = 0;
	char hit_result = '\0';
	print_board(target_board);
	do
	{
		int tar_x = rng_coord() - 1;
		int tar_y = rng_coord() - 1;
		
		printf("attacking %c %d!\n", tar_x + 65, tar_y + 1);
		if (check_coord(target_board, tar_x, tar_y) == SEA_CHAR)
		{
			hit_result = check_coord(opponent_board, tar_x, tar_y);
			if (hit_result == SEA_CHAR) {
				printf("That's a MISS...\n");
				update_board(target_board, tar_x, tar_y, MISS_CHAR);
				print_board(target_board);
				press_continue;
				turn += 1;
			}
			else {
				printf("That's a HIT!\n");
				update_board(target_board, tar_x, tar_y, HIT_CHAR);
				print_board(target_board);
				press_continue();
				//update_opponent_fleet(hit_result, opponent_fleet, player_points);
				turn += 1;
			}
		}
		printf("Oh, that spot has already been attacked, I'll Try again.\n");
	} while (turn == 0);
	return 1;
}

char check_coord(char board[][GRID_SIZE], int shot_x, int shot_y) {
	//recieves board, x, and y as argument.
	//reads what's in the cell of passed in board for coord [y][x]
	//returns what's found there.
	return board[shot_y][shot_x];

}

bool placement_check(char board[][GRID_SIZE], struct boat ship, int x, int y, int horizontal) {
	
	if (validate_in_bounds(ship, x, y, horizontal) == true) {
		if (validate_empty_space(board, ship, x, y, horizontal) == true) {
			return true;
		}
	}
	else return false;

}


bool validate_empty_space(char board[][GRID_SIZE], struct boat ship, int x, int y, int horizontal){
	ship.x_coord = x;
	ship.y_coord = y;
	switch (horizontal) {
	case '|':
		for (int i = 0; i < ship.size; i++)
		{
			//printf("compare char: %d\n", board[ship.y_coord + i][ship.x_coord]);
			if (board[ship.y_coord + i][ship.x_coord] != SEA_CHAR) {
				return false;
			}
		}
		return true;
	case '-':
		for (int i = 0; i < ship.size; i++)
		{
			//printf("compare char: %d\n", board[ship.y_coord][ship.x_coord + i]);
			if (board[ship.y_coord][ship.x_coord + i] != SEA_CHAR) {
				return false;
			}
		}
		return true;
	}
}

bool validate_in_bounds(struct boat ship, int x, int y, int horizontal) {
	ship.x_coord = x;
	ship.y_coord = y;
	switch (horizontal) {
	case '|':
		if ((y + ship.size) >= GRID_SIZE) {
			return false;
		}
		else return true;
		//break;
	case '-':
		if ((x + ship.size) > GRID_SIZE) {
			return false;
		}
		else return true;
		//break;
	}
}

void randomly_place_ships_on_board(char board[][GRID_SIZE], struct boat ship) {
	//same algorithm as manual, but origin is rng 1-10. mapped to board. check for bounds. 
	//maybe want to keep track of bounds, or use the previous to 
	do {

		int x = rng_coord();
		int y = rng_coord();
		char horiz = rng_orientation();

		//printf("validating x: %d, y: %d, o: %c\n", x, y, horiz);
		if (placement_check(board, ship, x, y, horiz)) {
			place_boat(board, ship, x, y, horiz);
			break;
		}
	} while (true);
}

void manually_place_ships_on_board(char board[][GRID_SIZE], struct boat ship) {
	do {
		bool board_check = false;
		bool place_check = false;
		print_board(board); //to reference what is where currently.

		printf("Place your %s ensign! %d spaces.\n", ship.name, ship.size);
		//recieve input from player. X, Y,and orientation.
		int x = get_x_coord();
		int y = get_y_coord();
		char horiz = get_horizontal();
		//validates input. Checks to ensure placement is in-ocean. and not overlapping ships.
		board_check += validate_in_bounds(ship, x, y, horiz);
		place_check += validate_empty_space(board, ship, x, y, horiz);
		if (place_check == true && board_check == true) {
			place_boat(board, ship, x, y, horiz); //updates the board if placement is valid.
			break;
		}
		else if (board_check == false)
		{
			system("cls");
			printf("Incorrect placement! \nOut of Bounds. \nTry again\n");
		}
		else if (place_check == false)
		{
			system("cls");
			printf("Incorrect placement! \nYou cannot overlap ships. \nTry again\n");
		}
	} while (true);
	system("cls");
}


int rng_coord(void) {
	return (rand() % 10 + 1);
}

char rng_orientation(void) {
	//char horiz = NULL;
	int rng = (rand() % 100 + 1);
	if (rng > 50) {
		return '-';
	}
	else return '|';
}

int get_x_coord(void){
	char z;
	printf("Input X coordinate (capital letter): ");
	scanf(" %c", &z);
	z = toupper(z); 
	return (int)z - 65;
}
int get_y_coord(void) {
	int a;
	printf("Input y coordinate (row number): ");
	scanf("%d", &a);
	return a - 1;
}

char get_horizontal(void) {
	char horizontal = NULL;
	do
	{
		printf("place boat Vertically (|) or Horizontally? (-) : ");
		scanf(" %c", &horizontal);
		printf("\n");
	} while (!(horizontal == '|' || horizontal == '-'));
	return horizontal;
}

//place boat does just that. Coordinates and orientation passed into it.
//so the Random placer and Human placer can both work.

void place_boat(char board[][GRID_SIZE], struct boat ship, int x, int y, int horizontal) {
	ship.x_coord = x;
	ship.y_coord = y;

	//if (validate_in_bounds(board, ship, x, y, horizontal) == true && validate_empty_space(board,ship,x,y,horizontal) == true) {
		switch (horizontal) {
		case '|':
			for (int i = 0; i < ship.size; i++)
			{
				//board[ship.y_coord + i][ship.x_coord] = ship.symbol;
				update_board(board, ship.x_coord, ship.y_coord + i, ship.symbol);
			}
			break;
		case '-':
			for (int i = 0; i < ship.size; i++)
			{
				//board[ship.y_coord][ship.x_coord + i] = ship.symbol;
				update_board(board, ship.x_coord + i, ship.y_coord, ship.symbol);
			}
			break;
		}
	//}
	/*else {
		printf("whoops. That location will take you out of bounds. Try a new x, y, and orientation.\n");
		ship.x_coord = get_x_coord();
		ship.y_coord = get_y_coord();
		horizontal = get_horizontal();
	}*/


	//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-++
	//1. choose a ship to place. - logic/track so it's only placed once. - bilt into struc array fleet[].					  +
	//2. choose horizontal or vertical orientation. //outside fcn, place													  +
	//3. choose where to 'start' it. : answer A2 - origin point																  +
	//4. check if it fits. - math makes boat boundary < perimiter, and not equal other boats. Start over if it doesn't. 	  +
	//	if board_spot[x][y] is "sea-char" at boat[0] and boat[max-1] {execute} else fail.									  +
	//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-++
}

//returns true for player 1, returns false for player 2. 
//I'm hoping to use the binary t or f to start the game. Rather than 1 or 2....but that may not work. Idk.
int select_who_starts_first(void){
	int choice = NULL;
	printf("Who's on first? \n");
	printf("1. Player 1 \n");
	printf("2. Player 2 \n");
	printf("3. Random\nInput Selection: ");
	scanf("%d", &choice);
	
	switch (choice) {
	case 1 :
		return 1;
		break;
	case 2: 
		return 0;
		break;
	case 3:
		if ((rand() % 100 + 1) % 2 == 0) {
			return 0;
		}
		else return 1;
		break;
	}
}

//4 boards need initializing. P1 ocean, p1 target. P2 ocean, p2 target.
// p2 boards never need to be displayed. 
// a player ocean uses "sea-char" for empty space. Use 'C's for carrier. 'B's for battleship. '
// a target ocean uses "sea-char" for empty space. X for hits. O for misses.
void initialize_game_board(char board[GRID_SIZE][GRID_SIZE], int rows, int cols) {
	for (int row_index = 0; row_index < rows; ++row_index)
	{
		for (int col_index = 0; col_index < cols; ++col_index)
		{
			//int a = SEA_CHAR;
			//board[row_index][col_index] = a;
			update_board(board, row_index, col_index, SEA_CHAR);
		}
	}
}

void print_board(char game_board[GRID_SIZE][GRID_SIZE]) {
	printf("   ");
	for (int i = 0; i < GRID_SIZE; i++) { //prints top row of letters.
		printf("%c ", 65 + i);
	} printf("\n");
	for (int i = 0; i < GRID_SIZE; i++) //nested for loop prints game board.
	{
		printf("%2d ", i + 1);
		for (int j = 0; j < GRID_SIZE; j++)
		{
			printf("%c ", game_board[i][j]);
		}
		printf("\n");
	}
}

void welcome_screen(void) {
	draw_title_art();
	draw_boat_art();
	printf("\n\nPress Enter key\n");
	//fflush(stdin);
	//getchar();	//this getchar() is inteded to pause the program, and it works. The program pauses here. When the splash screen is drawn. But in the other functions it only pauses *after* the first getchar().
				//There must be something in the stream, hence the preceeding fflush(stin) to clearing the stream (no go). but it only works the first time here in this function, and not the gameplay loop, or the print rules function.
	system("cls");
}
void draw_title_art(void)
{
	printf(" _______  _______  _______  _______  ___      _______  _______  __   __  ___   _______  __ \n");
	printf("|  _    ||   _   ||       ||       ||   |    |       ||       ||  | |  ||   | |       ||  |\n");
	printf("| |_|   ||  |_|  ||_     _||_     _||   |    |    ___||  _____||  |_|  ||   | |    _  ||  |\n");
	printf("|       ||       |  |   |    |   |  |   |    |   |___ | |_____ |       ||   | |   |_| ||  |\n");
	printf("|  _   | |       |  |   |    |   |  |   |___ |    ___||_____  ||       ||   | |    ___||__|\n");
	printf("| |_|   ||   _   |  |   |    |   |  |       ||   |___  _____| ||   _   ||   | |   |     __ \n");
	printf("|_______||__| |__|  |___|    |___|  |_______||_______||_______||__| |__||___| |___|    |__|\n");
}

void draw_boat_art(void) {
	printf("\n\n");
	printf("                                           |__                                       \n");
	printf("                                           |\\/                                       \n");
	printf("                                           ---                                       \n");
	printf("                                           / | [                                     \n");
	printf("                                    !      | |||                                     \n");
	printf("                                  _/|     _/|-++'                                    \n");
	printf("                              +  +--|    |--|--|_ |-                                 \n");
	printf("                           { /|__|  |/\\__|  |--- |||__/                              \n");
	printf("                          +---------------___[}-_===_.'____                 /\       \n");
	printf("                      ____`-' ||___-{]_| _[}-  |     |_[___\\==--            \/   _   \n");
	printf("       __..._____--==/___]_|__|_____________________________[___\\==--____,------' .7 \n");
	printf("      \\|                                                                     BB-61/  \n");
	printf("       \\_________________________________________________________________________|   \n");

}

void print_game_rules(void) {
	system("cls");
	printf("\nThe Rules of Battleship:\n");
	printf("This game simulates tactical naval warfare between two players. (read: opponents)\n It is not for the weak-willed, or faint of heart. \n\n");
	printf("The theatre of war lies in two 'oceans', represented as a 10 x 10 grid. one for each faction. \n");
	printf("Each faction has a home ocean, and a view of their opponent\'s ocean, enshrouded by the fog of war.\n\n");
	printf("Each faction begins with the same number of same-sized ships they get to position at will in their home ocean.\n");
	printf("The goal is to sink all of the opponens's ships, by vollying attacks into the opopnent\'s ocean.\n\n");
	printf("Each Volley is targetted by an alphanumerical coordinate, fitting a grid system.\n");
	printf("The columns west to east are labelled with letters A - J, and the rows north to south are numbered 1 - 10.\n");
	printf("The opponent will respond if the attacked coordinate either a hit a ship, or missed a shipo.\nThe player can record the result on their 'target' ocean for tracking.\n\n");
	printf("Every ship, can only withstand a finite number of hits, before sinking. \nIf a ship sustains sufficient damage to be rendered inoperable, a \'sunk\' announcmenet is made.\n");
	printf("The first faction to sink all of their opponent's ships is declared the victor, and the game is over.\n\n");
	printf("The battle may have ended, but war will always remain...\n");
	press_continue();
}

void press_continue(void) {
	printf("\n");
	system("pause");
}

int sequential_search(char list[], int size, char target, int* target_index_ptr)
{
	*target_index_ptr = -1;
	int index = 0, found = 0;

	while (!found && index < size) // we've not found our target
	{
		//search for target
		if (list[index] == target)
		{
			found = 1;
			*target_index_ptr = index; // set where we found target in list
		}
		++index;
	}

	return found;
}

bool is_odd(int integer) {
	int a = 0;
	a = integer % 2;
	if (a == 0) {
		return false;
	}
	else return true;
}