#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void fcn(int* ct, int arr[]);

typedef struct rung {
    int width;
    int length;
}Rung;

typedef struct ladder
{
    Rung rungs[5];
}Ladder;

//void print_elements(Ladder* gArr[]);
void print_array(int arr[], int size);
void print_rung(Rung rung[], int size);
void init_ladder(Ladder lddr, int size);
void print_ladder(Ladder lddr, int size);

int main(void)
{
    int qt = 0;
    //Rung steps[5]= { {9,8},{7,6},{5,4},{3,2},{1,0} };

    Ladder laddy = { 0 };
    init_ladder(laddy, 5);
    print_ladder(laddy, 5);
   /* for (int i = 0; i < 5; i++)
    {
        laddy[i] 
    }*/
    
    
    //print_rung(&steps, 5);

   /* int num_array[10] = { 0, 1, 2, 3, 4, 5, 6, 7,8,9 };
    print_array(&num_array, 10);
    print_array(&num_array, 10);*/

    /*Rung r1 = { 2, 4 };
    print_rung(r1);*/
        
    

    //print_elements(&unique_array);

   /* fcn(&qt, unique_array);
    printf("count now: %d \n", qt);
    fcn(&qt, unique_array);
    printf("count now: %d \n", qt);*/

    return 0;
}

void init_ladder(Ladder lddr, int size) {
    for (int i = 0; i < 5; i++)
    {
        lddr.rungs[i].length = i;
        lddr.rungs[i].width = i + 1;
    }
}

void print_ladder(Ladder lddr, int size) {
    for (int i = 0; i < size; i++)
    {

        printf("rung: %d\t width: %d\n", i, lddr.rungs[i].width);
        printf("rung: %d\t length: %d\n", i, lddr.rungs[i].length);
    }
}


void print_rung(Rung rung[], int size) {
    for (int i = 0; i < 5; i++)
    {
        printf("rung: %d\twidth: %d\n", i, rung[i].width);
        printf("rung: %d\tlength: %d\n", i, rung[i].length);
    }
}

void print_array(int arr[], int size) {
    for (int i = 0; i < size; i++)
    {
        if (i % 2 == 0) {
            arr[i] += 10;
            printf("evens: %d\t", arr[i]);
        }
        else
        {
            printf("odds: %d\n", arr[i]);
        }
    }

}
//void print_elements(Ladder* gArr[])
//{
//    for (int i = 0; i < 5; i++)
//    {
//        printf("evens: %d\t", gArr->rungs[i]->length);
//        printf("odds: %d\n", gArr->rungs[i]->width);
//    }
//}

void fcn(int* ct, int arr[]) {
    int i = *ct + 1, number = 0, interval = 0;
    printf("\nhow many? ");
    scanf("%d", &number);
    interval = (i + number);

    for (; i < interval; i++)
    {
        printf("index: %d, value: %d\n", i, arr[i]);
        
    }
    
    *ct = i -1;
}