/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define HAND_SIZE 5

//struct declaration. before all functions so they are global

typedef struct card
{
	int face;
	int suit;
}Card;

typedef struct hand
{
	Card hand[HAND_SIZE];
}Hand;

typedef struct target {
	int left;
	int right;
}T;

//pretty graphcis. Reminiscent of Craps, Yahtzee and Battleship
void welcome_screen(void);
void draw_title_art(void);
void draw_card_art(void);
void print_game_rules(void);
void press_continue(void);
void draw_hand_art(void);

//shuffle cards in the initialized deck array
void shuffle(int wDeck[][13]);

//deal a hand of cards from the deck.
void deal(const int wDeck[][13], const char wFace[], const char wSuit[], Hand* wHand, int* wDealt, int quantity);

//print a whole hand - actually calls print_card 5x
void print_hand(Hand* wHand, const char* wFace[], const char* wSuit[]);

//house the drawing feature. will call deal in there too.
void redraw(const int wDeck[][13], const char* wFace[], const char* wSuit[], Hand* wHand, int* wDealt, int quantity);

void move_nulls_front(int arr[], int size);
void swap(int* arr, int left, int right);