#include "PA4_Header.h"

//Prints out the rules of the game of "craps".
void print_game_rules(void){
	system("cls");
	printf("\n\tA player  (dat's you) rolls two dice see.\n Each die has six sides, each side contains 1, 2, 3, 4, 5, and 6 spots respectively see? \n \
		You's takes both dice and gently huck 'em into this here table. (And no funny business see?)\n\
		After the dice have come to rest, the sum of the spots on the two upward faces is calculated. \n\
		- If the sum is 7 or 11 on the first throw, the player wins, good fah' yous. \n\
		- If the sum is 2, 3, or 12 on the first throw (called \"craps\"), the player loses\n \t\t(meanin', the \"house\" wins, heh heh try again). \n\
		- If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's \"point.\" \n\
		- To win, you must continue rolling the dice until you \"make your point.\" \n\
		- All winnings pay out 1:1 with wagers\n\
		- The player loses by rolling a 7 before making the point.\n\nGood Luck!\n\n\
		Press 'enter' whenever you're done reading.\n");
	getchar();
	system("CLS");
}

//core game loop. This will exectue from the main menu. And call all of the elements of play for our game.
int game_loop(void) {
	double bank = 0.0, starting_stake = 0;
	double wager = 0.0;
	int bet_check = 0;
	int roll_count = 0;
	int roll_result = 0;
	int die_check = "\0";
	int point = 0;
	//char cont_char = 'y'; neat feature. no time to debug.

	//while (cont_char == 'y' || cont_char == 'Y') {
		printf("\n Excellent! Let's get started.\n");

		starting_stake = get_bank_balance();
		bank = starting_stake;

		//outer core game loop. starts with a wager. Resets the 'point' and roll counter.
			//inner game loop rolls dice, checks results, and continues to roll if result is non-losing.
			//inner game loop updates bank +/- wager on exit, restarting at top of outer loop, provicded bank balance is non-zero.
		do {
			point = 0;
			roll_count = 0;
			wager = get_wager_amount();
			bet_check = check_wager_amount(wager, bank);

			if (bet_check == 1) { //if the wager is valid, proceed to play. Else exit the play loop.
				//now in the play loop, roll the dice!
				do {
					printf("\nBank: %lf\n", bank);
					printf("\nWager: %lf\n", wager);
					roll_result = calculate_sum_dice();
					printf("\nYou rolled a %d!\n", roll_result);
					roll_count++;  //dice were thrown, roll count go up.

					//if this is the first dice roll, then we determine win, loss, or set the point.
					if (roll_count == 1) {
						die_check = is_win_loss_or_point(roll_result);

						if (die_check == -1) {
							printf("Point set! %d is now ON.", roll_result);
							point = roll_result;
						}
						else if (die_check == 0) {
							bank = adjust_bank_balance(bank, wager, die_check);
							//printf("\nBank: %lf\n", bank);
						}
						else if (die_check == 1) {
							printf("that's a win!\n");
							bank = adjust_bank_balance(bank, wager, die_check);
							//printf("\nBank: %lf\n", bank);
						}
						/*chatter_messages(roll_count, die_check, starting_stake, bank);
						printf("\n\ninner loop. Press Enter key to continue rolling!");
						getchar();*/
					}
					else {
						die_check = is_point_loss_or_neither(roll_result, point);
						if (die_check == 1) {
							bank = adjust_bank_balance(bank, wager, die_check);
							//chatter_messages(roll_count, die_check, starting_stake, bank);
							//printf("\nBank: %lf\n", bank);
						}
						else if (die_check == 0) {
							bank = adjust_bank_balance(bank, wager, die_check);
							//chatter_messages(roll_count, die_check, starting_stake, bank);
							//printf("\nBank: %lf\n", bank);
						}
					}
					chatter_messages(roll_count, die_check, starting_stake, bank);
					printf("\nBank: %lf\n", bank);
					printf("\n\nPress Enter key to continue.");
					getchar();
				} while (die_check < 0);

			}
			else {
				printf("\nBegin the game again to reload your bank for some mo' CRAPs!\n");
				break;
			}
			//printf("\nPlay again? (y/n): ");
			//scanf("% c", &cont_char);
		} while (bet_check != 0);
	//} continue loop would be nice. but no time to debug.

	return 1;
}

//Prompts the player for an initial bank balance from which wagering will be added or subtracted.The player entered bank balance(in dollars, i.e.$100.00) is returned.
double get_bank_balance(void){
	double bank_bal = 0.0;
	printf("\nWhat kinda stake you rolling with tongiht? (this is your total bank balance, in dollars): $");
	scanf("%lf", &bank_bal);
	
	if (bank_bal >= 10000) {
		printf("\nOh! we have a High-roller in da haus!\nRight this way my esteemed guest and collegue. Allow me to show you to our exclusive tables...\n");
	}
	//reduces bank_bal to 2 decimal places.
	bank_bal = (floor(bank_bal * 100)) / 100;
	return bank_bal;
} 

//Prompts the player for a wager on a particular roll.The wager is returned.
double get_wager_amount(void){

	double wager = 0.0;
	printf("\nPlease place your wager: $");
	scanf("%lf", &wager);
	
	if (wager < 0) {
		printf("\n'ey 'ey 'ey, what you tryin'a pull?! Your money gotta be a real positive value see! Try again bucko. I'll wait...\n");
		get_wager_amount();
	}
	else if (wager == 0) {
		printf("\noh just practicin' then? Alright, I guess if you want to be boring go ahead.\n");
	}
	return wager;
} 

//Checks to see if the wager is within the limits of the player's available balance. 
//If the wager exceeds the player's allowable balance, then 0 is returned otherwise 1 is returned.
int check_wager_amount(double wager, double balance){

	if (wager > balance) {
		printf("\nI dun' think you can afford that bet! try again mate.\n");
		return 0;
	}
	else if (wager == balance) {
		printf("\nWoah nelly! We're goin all-in on this one!\n");
	}
	else if (wager < (.1 * balance)) {
		printf("\nAh you're just bein' shy, c'mon! gotta bet big to win big! \;-)\n");
	}
	return 1;
} 


//returns a random number between 1 and 6
int roll_die(void){
	int num;
	num = rand() % 6 + 1;
	draw_roll(num);  //displays the neat drawings of a roll, when it's rolled.
	return num;
} 

// Sums together the values of the two dice and returns the result.
//Note: this result may become the player's point in future rolls
int calculate_sum_dice(void) {
	
	int die1_value = roll_die();
	int die2_value = roll_die();
	return die1_value + die2_value;
}

/* Determines the result of the first dice roll.
If the sum is 7 or 11 on the first roll, the player wins and 1 is returned.
If the sum is 2, 3, or 12 on the first throw (called "craps"), the player loses(i.e.the "house" wins) and 0 is returned.
If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's "point" and -1 is returned.*/
int is_win_loss_or_point(int sum_dice) {
	if (sum_dice == 7 || sum_dice == 11) {
		return 1;
	}
	else if (sum_dice == 2 || sum_dice == 3 || sum_dice == 12) {
		return 0; 
	}
	else {
		return -1;
	}
}

//Determines the result of any successive roll after the first roll.
//If the sum of the roll is the point_value, then 1 is returned.
//If the sum of the roll is a 7, then 0 is returned.
//Otherwise, -1 is returned.
int is_point_loss_or_neither(int sum_dice, int point_value) {
	if (sum_dice == point_value) {
		return 1;
	}
	else if (sum_dice == 7) {
		return 0;
	}
	else {
		return -1;
	}
}

//If add_or_subtract is 1, then the wager amount is added to the bank_balance.
//If add_or_subtract is 0, then the wager amount is subtracted from the bank_balance.
//Otherwise, the bank_balance remains the same.
//The bank_balance result is returned.
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract) {
	if (add_or_subtract == 1) {
		return wager_amount + bank_balance;
	}
	else if (add_or_subtract == 0) {
		return bank_balance - wager_amount;
	}
	else {
		return bank_balance;
	}
}

//Prints an appropriate message dependent on:
//the number of rolls taken so far by the player,
//the current balance, 
//and whether or not the player just won his roll.
//The parameter win_loss_neither indicates the result of the previous roll

void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance) {
	//based on roll number. Writes chatter based on first or subequent roll. 
	if (number_rolls == 1 && win_loss_neither == 0) {
		//first roll is a loss, must be a craps.
		printf("that's a CRAPS loss\n");
	}
	//the following 'streak' cheers are based on the length of a rolling streak. 
	//the win_loss_neither must continue to be neither, becasue it's called in every inner-game loop. Checks against roll number for the streak.
	else if (number_rolls >= 10 && win_loss_neither == -1) {
		//if you're 10 rolls in and still chasing your point, that's gotta be a new record.
		printf("This has to be a new record! omg!\n");
	}
	else if (number_rolls >= 5 && win_loss_neither == -1) {
		//if you're 5 rolls in and still chasing your point, that's pretty susepenseful.
		printf("OMG the suspense is killing me!\n");
	}
	else if (number_rolls >= 3 && win_loss_neither == -1) {
		//3 rolls in and still chasing your point, is pretty fun.
		printf("You're on a roll!! Keep rolling!");
	}

	if (win_loss_neither == 1) {
		printf("\nHUZZAH! You've won! What are the odds?!\n");
		printf("It only took you %d roll!\n", number_rolls);
	}
	else if (win_loss_neither == 0 && current_bank_balance <= 0) {
		printf("\nTell you what, I'll let you try again....(if'n yous can afford it)\n");
		printf("Restart to program to reload your bank.\n");
	}

	if (current_bank_balance >= 2 * initial_bank_balance && win_loss_neither == 1) {
		printf("your winnings are up! You're on a Roll! (get it? roll! hahaha :-D)!\n");
	}else if (current_bank_balance >= initial_bank_balance && win_loss_neither == 0) {
		printf("Hey it's not so bad, you're still up in the long run!\n");
	}
}

//function to draw a neat picture to go with the logo
void draw_dice_art(void) {
	printf("               .-------.   ______		\n");
	printf("              /   o   /|  /\\     \\	\n");
	printf("             /_______/o| /o \\  o  \\	\n");
	printf("             | o     | |/   o\\_____\\	\n");
	printf("             |   o   |o/\\o   /o    /	\n");
	printf("             |     o |/  \\ o/  o  /	\n");
	printf("             '-------'    \\/____o/		\n\n");
}

//function to draw a neat logo to go with the picture
void draw_craps_art(void) {
	printf("\n");
	printf("    ______                                          __  \n");
	printf("   /      \\                                        |  \\ \n");
	printf("  |  $$$$$$\\  ______   ______    ______    _______ | $$ \n");
	printf("  | $$   \\$$ /      \\ |      \\  /      \\  /       \\| $$ \n");
	printf("  | $$      |  $$$$$$\\ \\$$$$$$\\|  $$$$$$\\|  $$$$$$$| $$ \n");
	printf("  | $$   __ | $$   \\$$/      $$| $$  | $$ \\$$    \\  \\$$ \n");
	printf("  | $$__/  \\| $$     |  $$$$$$$| $$__/ $$ _\\$$$$$$\\ __  \n");
	printf("   \\$$    $$| $$      \\$$    $$| $$    $$|       $$|  \\ \n");
	printf("    \\$$$$$$  \\$$       \\$$$$$$$| $$$$$$$  \\$$$$$$$  \\$$ \n");
	printf("                               | $$                     \n");
	printf("                               | $$                     \n");
	printf("                                \\$$                     \n");
	printf("													    \n");
	printf("\n");
}

//function to draw a nice splash screen, to begin and end the game.
void draw_splash_screen(void) {
	draw_craps_art();
	draw_dice_art();
	printf("\n\nPress Enter key\n");
	getchar();
	system("cls");
}

void draw_roll(int number) {
	if (number == 1) {
		printf("+------------+\n");
		printf("|            |\n");
		printf("|            |\n");
		printf("|     ()     |\n");
		printf("|            |\n");
		printf("|            |\n");
		printf("+------------+\n");
	}
	else if (number == 2) {
		printf("+------------+\n");
		printf("|            |\n");
		printf("|        ()  |\n");
		printf("|            |\n");
		printf("|  ()        |\n");
		printf("|            |\n");
		printf("+------------+\n");
	}
	else if (number == 3) {
		printf("+------------+\n");
		printf("| ()         |\n");
		printf("|            |\n");
		printf("|     ()     |\n");
		printf("|            |\n");
		printf("|         () |\n");
		printf("+------------+\n");
	}
	else if (number == 4) {
		printf("+------------+\n");
		printf("| ()      () |\n");
		printf("|            |\n");
		printf("|            |\n");
		printf("|            |\n");
		printf("| ()      () |\n");
		printf("+------------+\n");
	}
	else if (number == 5) {
		printf("+------------+\n");
		printf("| ()      () |\n");
		printf("|            |\n");
		printf("|     ()     |\n");
		printf("|            |\n");
		printf("| ()      () |\n");
		printf("+------------+\n");
	}
	else if (number == 6) {
		printf("+------------+\n");
		printf("| ()      () |\n");
		printf("|            |\n");
		printf("| ()      () |\n");
		printf("|            |\n");
		printf("| ()      () |\n");
		printf("+------------+\n");
	}
}