#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

//Prints out the rules of the game of "craps".
void print_game_rules(void);

//Core game loop. Will be called from Main Menu.
int game_loop(void);

//Prompts the player for an initial bank balance from which wagering will be added or subtracted.The player entered bank balance(in dollars, i.e.$100.00) is returned.
double get_bank_balance(void);

//Prompts the player for a wager on a particular roll.The wager is returned
double get_wager_amount(void);

//Checks to see if the wager is within the limits of the player's available balance. If the wager exceeds the player's allowable balance, then 0 is returned, otherwise 1 is returned.
int check_wager_amount(double wager, double balance);

//-Rolls one die.This function should randomly generate a value between 1 and 6, inclusively.Returns the value of the die.
int roll_die(void);

//Sums together the values of the two dice and returns the result.Note: this result may become the player's point in future rolls.
int calculate_sum_dice(void);

// Determines the result of thefirst dice roll. Described in better detail in PA4.c
int is_win_loss_or_point(int sum_dice);

//Determines the result of any successive roll after the first roll. Described in better detail in PA4.c
int is_point_loss_or_neither(int sum_dice, int point_value);

//Otherwise, the bank_balance remains the same.
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract);

//Prints an appropriate message dependent on the number of rolls taken so far by the player, the current balance, and whether or not the player just won his roll.
void chatter_messages(int number_rolls, \
	int win_loss_neither, \
	double initial_bank_balance, \
	double current_bank_balance);
//function to draw a neat picture to go with the logo	
void draw_dice_art(void);

//function to draw a neat logo to go with the picture	
void draw_craps_art(void);

//function to display a splash screen, intended to use at the beginning and end of our game.
void draw_splash_screen(void);

//function to draw the dice face:
void draw_roll(int number);
