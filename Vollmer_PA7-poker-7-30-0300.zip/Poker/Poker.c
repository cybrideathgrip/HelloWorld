/*
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/

#include "Poker.h"

/* shuffle cards in deck */

void shuffle(int wDeck[][13])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* for each of the 52 cards, choose slot of deck randomly */
	for (card = 1; card <= 52; card++)
	{
		/* choose new random location until unoccupied slot found */
		do
		{
			row = rand() % 4;
			column = rand() % 13;
		} while (wDeck[row][column] != 0);

		/* place card number in chosen slot of deck */
		wDeck[row][column] = card;
	}
}

/* deal cards in deck */
void deal(const int wDeck[][13], const char wFace[], const char wSuit[], /*Hand* wHand,*/ Player* player, int* wDealt, int quantity)
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = *wDealt + 1;   /* card counter */
	int interval = card + quantity;
	int hand_index = 0;

	if (player->redraw == false || player->draw == HAND_SIZE) //this check, proceeds if this is your first hand, your want to redraw all 5 cards.
	{
		/* deal cards */
		for (; card < interval; card++)
		{
			//status check here; Time permitting. while(true) do the for loops. when you hit the if statement, change that local control variable.
			/* loop through rows of wDeck */
			for (row = 0; row <= 3; row++)
			{
				/* loop through columns of wDeck for current row */
				for (column = 0; column <= 12; column++)
				{
					//printf("column: %d\n", column);
					/* if slot contains current card, display card */
					if (wDeck[row][column] == card)
					{
						//if (wHand->hand[hand_index].face < 0)
						//{
							//printf("dealing %5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
							/*wHand->hand[hand_index].face = column;
							wHand->hand[hand_index].suit = row;*/
						player->hand.hand[hand_index].face = column;
						player->hand.hand[hand_index].suit = row;
						hand_index += 1;
						//printf("dealing %5s of %-8s%c", wFace[column], wSuit[row], card % 2 == 0 ? '\n' : '\t');
					//}
					}
				}
			}
		}
		*wDealt = card - 1; //update the 'dealt' counter.
	}
	else //if not the first hand, or you redraw 1-4 cards. 
	{
		/* deal cards */
		for (; card < interval; card++)
		{
			//status check here; Time permitting. while(true) do the for loops. when you hit the if statement, change that local control variable.
			/* loop through rows of wDeck */
			for (row = 0; row <= 3; row++)
			{
				/* loop through columns of wDeck for current row */
				for (column = 0; column <= 12; column++)
				{
					//printf("column: %d\n", column);
					/* if slot contains current card, display card */
					if (wDeck[row][column] == card)
					{
						//I wonder if the form player->hand.hand[i] = {0,0} is a valid check. probably not.
						if (player->hand.hand[hand_index].face < 0 && player->hand.hand[hand_index].suit < 0)
						{
							for (; hand_index < HAND_SIZE; hand_index++)
							{
								player->hand.hand[hand_index].face = column;
								player->hand.hand[hand_index].suit = row;
							}
						}						
					}
				}
			}
		}
		*wDealt = card - 1; //update the 'dealt' counter.
	}
}

void select_discard(Player* player)
{
	player->draw = 0;
	int discard = 0;
	do
	{
		printf("How many cards to redraw? (zero is acceptable. integers less than zero or greater than are unaccpetable.");
		scanf("%d", &player->draw);
	} while (player->draw > 5 && player->draw < 0);

	printf("Select which cards to discard (separated by spaces: ");
	for (int i = 0; i < player->draw; i++)
	{
		scanf("%d", &discard);
		player->hand.hand[discard - 1].face = -1;
		player->hand.hand[discard - 1].suit = -1;
	}
	player->redraw = true;
}

void redraw(const int wDeck[][13], const char* wFace[], const char* wSuit[],/*Hand* wHand,*/ Player* player, int* wDealt, int quantity)
{
	int discard = NULL, ct = 0; //discard for the index. 
	while (true)
	{
		printf("Choose cards to discard and redraw, by card number: ");
		scanf("%d", discard);
		if (discard > 0 && discard < 5)
		{	
			--discard;	//because the given value is a number for humans, but an index for the array: wHand->hand[]
			/*wHand->hand[discard].face = -1;
			wHand->hand[discard].suit = -1;*/
			player->hand.hand[discard].face = -1;
			player->hand.hand[discard].suit = -1;
			ct += 1;	//track how many cards are discarded, how many need to be redrawn.
		}
	}

}
//void game_loop();

	  //deck already initialized, and shuffled.
  //begin loop.
	  //ante up p1, p2. 
		//pot += p1-bet ; 
		//pot += p2-bet ;

	  //deal hand for p1. 
	  //deal hand for p2.

	  //bet, check p1, 
	  //bet, check, fold p2,

	  //draw N cards p1
	  //draw N card p2

	  //bet, check, fold p1, 
	  //bet, check, fold p2,

	  //compare hands p1 p2.

	  //decide winner
  //play again or exit.

//The intended result will take a player's frequency arrays and check for all winning combinations in order from most to least valuable.

void make_freq_arrays(Player* player)
{
	reset_freq_arrays(player);
	int col = 0, row = 0;
	for (int i = 0; i < HAND_SIZE; i++)
	{
		col = player->hand.hand[i].face;
		//fFace[pHand->hand[i].face] += 1;
		player->fFace[col] += 1;
	}

	for (int i = 0; i < HAND_SIZE; i++)
	{
		row = player->hand.hand[i].suit;
		//fSuit[pHand->hand[i].suit] += 1;
		player->fSuit[row] += 1;
	}
}

void reset_freq_arrays(Player* player)
{
	for (int i = 0; i < 4; i++)
	{
		player->fFace[i] = 0;
		player->fSuit[i] = 0;
	}
	for (int i = 4; i < 13; i++)
	{
		player->fFace[i] = 0;
	}	
}

void decide_points(Player* player)
{
	int t = 0;
	player->points = 0;
	while (player->points == 0 && t < 11)
	{
		t += 1;
		switch (t)
		{
		case 1: if (validate_RFlush(player)) {
			player->points = 100;
			printf("A ROYAL FLUSH! OMG! are you serious? \nThat's rarer than a Charizard holo card!!\nYou totally won this round.");
		}
			  break;
		case 2: if (validate_str8_flush(player)) {
			player->points = 90;
			printf("Straight Flush! Very Nice!\n");
		}
			  break;
		case 3: if (validate_4kind(player)) {
			player->points = 80;
			printf("Four is the magic number!\n");
		}
			  break;
		case 4: 
			if (validate_full_house(player))
			{
			player->points = 70;
			printf("Animal House? School House? nope! That's a FULL House!\n");
			}
			  break;
		case 5: if (validate_flush(player)) {
			player->points = 60;
			printf("Nice Flush! often overlooked, well done.");
		}
			  break;
		case 6: if (validate_str8(player)) {
			player->points = 50;
			printf("Straight on to victory!\n");
		}
			  break;
		case 7: if (validate_3kind(player)) {
			player->points = 40;
			printf("Three of a kind!\n Good things happen in threes...\n");
		}
			  break;
		case 8: if (validate_2_pair(player)) {
			player->points = 30;
			printf("A pair of pairs!\n");
		}
			  break;
		case 9: if (validate_pair(player)) {
			player->points = 20;
			printf("Two is better than one!\n");
		}
			  break;
		case 10: player->points = hi_card(player);
			break;
		}
	}
	return player->points;
}

bool validate_RFlush(Player* player) {
	if (player->fFace[0] == 1 && validate_flush(player))
	{
		for (int i = 9; i < 13; i++)
		{
			if (player->fFace[i] != 1) {
				return false;
			}
		}
		return true;
	}
	else return false;
}


bool validate_str8_flush(Player* player) {

	if(validate_flush(player) && validate_str8(player))
	{
		return true;
	}
	else return false;
}

bool validate_4kind(Player* player)
{
	for (int i = 0; i < 13; i++)
	{
		if (player->fFace[i] == 4) {
			return true;
		}
	}
	return false;
}

bool validate_full_house(Player* player)
{
	int pair_ct = 0;
	int three_ct = 0;
	for (int i = 0; i < 13; i++)
	{
		if (player->fFace[i] == 2) {
			pair_ct += 1;
		}
		if (player->fFace[i] == 3)
		{
			three_ct = 0;
		}
	}
	if (pair_ct == 1 && three_ct == 1)
	{
		return true;
	}
	else return false;
}

bool validate_flush(Player* player)
{
	for (int i = 0; i < 4; i++)
	{
		if (player->fSuit[i] == 5) {
			return true;
		}
	}
	return false;
}

bool validate_str8(Player* player)
{
	int str8_ct; 
	for (int i = 0; i < 9; i++)
	{
		str8_ct = 0;
		if (player->fFace[i] == 1)
		{
			for (int j = (i + 1); j < (i + 5); j++)
			{
				if (player->fFace[j] == 1)
				{
					str8_ct++;
					if (str8_ct == 4)
					{
						return true;
					}
				}
			}
		}
	}
	return false;
}

void decide_winner(Player* player1, Player* player2) 
{
	if (player1->points > player2->points)
	{
		printf("Player 1 wins the pot!");
	}
	else if (player2->points > player1->points)
	{
		printf("Player 2 wins the pot!");
	}
	else printf("Alright, we'll call it a draw.");
}

void reset_player(Player* player)
{
	for (int i = 0; i < HAND_SIZE; i++)
	{
		player->hand.hand[i].face = 0;
		player->hand.hand[i].suit = 0;
	}
	player->points = 0;
	player->draw = 0;
	player->redraw = 0;
}

//archived code. It was causing an infinite loop. Checking for a straight that's Q,K,A,2,3 is still worthwhile. 
//bool validate_A_str8(Player* player)
//{
//	int freq_array_2[13];
//	int j = 9;
//	for (int i = 0; i < 4; i++)
//	{
//		freq_array_2[i] = player->fFace[j];
//		++j;
//	}
//	for (int i = 0; i < 5; i++)
//	{
//		freq_array_2[i + 4] = player->fFace[i];
//	}
//	if (validate_str8(freq_array_2))
//	{
//		return true;
//	}
//	else return false;
//}


bool validate_3kind(Player* player)
{
	for (int i = 0; i < 13; i++)
	{
		if (player->fFace[i] == 3) {
			return true;
		}
	}
	return false;
}

bool validate_2_pair(Player* player)
{
	int pair_ct = 0;
	for (int i = 0; i < 13; i++)
	{
		if (player->fFace[i] == 2) {
			pair_ct += 1;
		}
	}
	if (pair_ct == 2)
	{
		return true;
	}
	else return false;
}

bool validate_pair(Player* player)
{
	for (int i = 0; i < 13; i++)
	{
		if (player->fFace[i] == 2) {
			printf("we have a pair!");
			return true;
		}
	}
	return false;
}

int hi_card(Player* player)
{
	if (player->fFace[0] == 1) {
		return 14;
	}
	else
	{
		for (int i = 13; i > 0; i--)
		{
			if (player->fFace[i] != 0)
			{
				return i;
			}
		}
	}
}

void print_hand(Player* player, const char* wFace[], const char* wSuit[])
{
	for (int i = 0; i < HAND_SIZE; i++) 
	{
		int col = player->hand.hand[i].face;
		int row = player->hand.hand[i].suit;
		
		//printf("row: %d, col: %d", row, col);
		printf("card %d: %5s of % -8s\n", i+1, wFace[col], wSuit[row]);
	}	
}

void move_nulls_front(int arr[], int size) {
	int ileft = 0, iright = 1;
	
	while (iright < size)
	{
		if (arr[ileft] != NULL && arr[iright] != NULL)
		{
			iright++;
		}
		else if (arr[ileft] != NULL && arr[iright] == NULL)
		{
			swap(&arr, ileft, iright);
		}
		else if (arr[ileft] == NULL && arr[iright] == NULL)
		{
			++ileft;
			++iright;
		}
		else if (arr[ileft] == NULL && arr[iright] != NULL)
		{

		}
	}
}

void swap(int* arr, int left, int right) 
{
	int temp = arr[left];
	arr[left] = arr[right];
	arr[right] = temp;
}

void press_continue(void) 
{
	printf("\n");
	system("pause");
}

void welcome_screen(void) 
{
	draw_title_art();
	draw_hand_art();
	system("pause");
}

void draw_title_art(void) 
{
	
	printf("    .------..------..------..------..------. \n");
	printf("    |P.--. ||O.--. ||K.--. ||E.--. ||R.--. | \n");
	printf("    | :/\\: || :/\\: || :/\\: || (\\/) || :(): | \n");
	printf("    | (__) || :\\/: || :\\/: || :\\/: || ()() | \n");
	printf("    | '--'P|| '--'O|| '--'K|| '--'E|| '--'R| \n");
	printf("    `------'`------'`------'`------'`------' \n");
}

void draw_card_art(void) 
{
	printf("               _____                      \n");
	printf("              |A .  | _____               \n");
	printf("              | /.\\ ||A ^  | _____        \n");
	printf("              |(_._)|| / \\ ||A _  | _____ \n");
	printf("              |  |  || \\ / || ( ) ||A_ _ |\n");
	printf("              |____V||  .  ||(_'_)||( v )|\n");
	printf("                     |____V||  |  || \\ / |\n");
	printf("                            |____V||  .  |\n");
	printf("                                   |____V|\n");
}

void draw_hand_art(void)
{
	printf("                  __                   \n\n");
	printf("             _..-''--'----_.           \n");
	printf("           ,''.-''| .---/ _`-._        \n");
	printf("         ,' \\ \\  ;| | ,/ / `-._`-.   \n");
	printf("       ,' ,',\\ \\( | |// /,-._  / /     \n");
	printf("       ;.`. `,\\ \\`| |/ / |   )/ /      \n");
	printf("      / /`_`.\_\\ \\| /_.-.'-''/ /      \n");
	printf("     / /_|_:.`. \\ |;'`..')  / /       \n");
	printf("     `-._`-._`.`.;`.\\  ,'  / /         \n");
	printf("         `-._`.`/    ,'-._/ /          \n");
	printf("           : `-/     \`-.._/           \n");
	printf("           |  :      ;._ (             \n");
	printf("           :  |      \\  ` \\          \n");
	printf("            \\         \\   |          \n");
	printf("             :        :   ;            \n");
	printf("             |           /             \n");
	printf("             ;         ,'              \n");
	printf("            /         /                \n");
	printf("           /         /                 \n");
	printf("                    /                  \n");
}

void print_game_rules(void) 
{
	
	system("cls");
	printf("\nThe Rules of Poker:\n");
	printf("Poker is a betting game played with cards.\n");
	printf("There are many variations in poker games, this one is called: 5-card draw.");
	printf("Every player is dealt a hand of 5 cards. \nAfter the deal a player may choose to re-draw any number of cards from the deck.\n");
	printf("The goal is to have the best hand of 5 cards among all the players.\n");
	printf("There are 10 possible combinations of cards in poker, each ranked in a specific hierarchy.\n\n");
	printf("That ranking is:\n----------------\n");
	printf("\n 1 - Royal Flush\n 2 - Straight Flush\n 3 - Four of a Kind\n 4 - Full House\n 5 - Flush\n");
	printf(" 6 - Straight\n 7 - Three of a kind\n 8 - Two Pair\n 9 - Pair\n10 - High Card\n\n");
	//would be nice to make this list a menu, that will display detail about each hand.
	printf("There are 3 round of betting that occur with every Hand.\n");
	printf("An initial bet, called an 'ante' must be made to be dealt into a hand.\n");
	printf("After the first hand of 5 cards are dealt, there is another round of betting. You may choose to increase your bet, or \"check\" and continue on.\n");
	printf("If another player raises the bet, and you do not want to meet that bet, you may fold, or call to proceed to the draw.\n"); 
	printf("there is a final round of betting to up the ante, or call a bluff.\n");
	printf("At any point after the deal, you may choose to fold. Avoiding obligation for additonal betting, while also forfeiting any potential winnings.\n");
	printf("You are NOT obligated to reveal your hand on a fold.\n");
	printf("ACES ARE HIGH. An Ace,2,3,4,&5 will NOT count as a straight.\n");
	printf("there are no wilds.\n");

	press_continue();
	system("cls");
}