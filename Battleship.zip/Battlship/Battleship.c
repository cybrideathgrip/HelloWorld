/*
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date: 7/16/2020

Description: Writing a game of battleship! To be played human vs computer.
			Placing 5 boats of mostly different size on a 10x10 grid and taking turns "firing" on a coordiate to determine hit or miss once per turn.
			The victor will hit all spaces of their opponents battleships before all thier own are hit.

Background:	we'll be using a lot of strings, arrays, introducing struts, and a 'computer controlled player' for the first time.

Relevant Formulas:
*/

#include "Battleship.h"

void update_board() {
	//after shot are taken "*" for hit and "m' for miss >.< I like X's and O's.
	//must update a player ocean, and the opposite player's target ocean. 
}

int is_winner() {
	//will have to accept player's list of boat structs. 
	//if all struct.boat.sunk = true for a player, the game ends, the opposite playeris the victor.
	//this check might have to be between every turn. or really after 17 shots, 34 turns. That's the minimum.

}

//bool check_shot(char board, int shot[x], int shot[y]) {
	//recieves board x & y as argument.
	//checks opponent's board for coord [x][y]
	//if shot[x][y] == 'sea-char' return false.
	//else return hit.
//}

void randomly_place_ships_on_board(void) {
	//same algorithm as manual, but origin is rng 1-10. mapped to board. check for bounds. 
	//maybe want to keep track of bounds, or use the previous to 

}
void manually_place_ships_on_board(void) {
	
	//1. choose a ship to place. - logic/track so it's only placed once.
	//2. choose horizontal or vertical orientation.
	//3. choose where to 'start' it. : answer A2
	//4. check if it fits. - math makes boat boundary < perimiter, and not equal other boats. Start over if it doesn't. 
		//if board_spot[x][y] is "sea-char" at boat[0] and boat[max-1] {execute} else fail.
}

//returns true for player 1, returns false for player 2. 
//I'm hoping to use the binary t or f to start the game. Rather than 1 or 2....but that may not work. Idk.
bool select_who_starts_first() {
	int choice = NULL;
	printf("Who's on first? \n");
	printf("1. Player 1 \n");
	printf("2. Player 2 \n");
	printf("3. Random\n");
	scanf("%d", &choice);
	
	switch (choice) {
	case 1 :
		return true;
		break;
	case 2: 
		return false;
		break;
	case 3:
		if ((rand() % 100 + 1) % 2 == 0) {
			return false;
		}
		else return true;
	}
}

//not even close. This just draws a board. Change name
//4 boards need initializing. P1 ocean, p1 target. P2 ocean, p2 target.
// p2 boards never need to be displayed. 
// use "sea-char" for MT space. Use 'C's for carrier. 'B's for battleship. '
void initialize_game_board(void) {
	char game_board[GRID_SIZE][GRID_SIZE];
	int a = 176;
	printf("   ");
	for (int i = 0; i < GRID_SIZE; i++) {
		printf("%c ", 65 + i);
	} printf("\n");
	for (int i = 0; i < GRID_SIZE; i++)
	{
		printf("%2d ", i + 1);
		for (int j = 0; j < GRID_SIZE; j++)
		{
			game_board[i][j] = a;
			printf("%c ", game_board[i][j]);
		}
		printf("\n");
	}
}
void welcome_screen(void) {
	draw_title_art();
	draw_boat_art();
	printf("\n\nPress Enter key\n");
	fflush(stdin);
	getchar();	//this getchar() is inteded to pause the program, and it works. The program pauses here. When the splash screen is drawn. But in the other functions it only pauses *after* the first getchar().
				//There must be something in the stream, hence the preceeding fflush(stin) to clearing the stream (no go). but it only works the first time here in this function, and not the gameplay loop, or the print rules function.
	system("cls");
}
void draw_title_art(void)
{
	printf(" _______  _______  _______  _______  ___      _______  _______  __   __  ___   _______  __ \n");
	printf("|  _    ||   _   ||       ||       ||   |    |       ||       ||  | |  ||   | |       ||  |\n");
	printf("| |_|   ||  |_|  ||_     _||_     _||   |    |    ___||  _____||  |_|  ||   | |    _  ||  |\n");
	printf("|       ||       |  |   |    |   |  |   |    |   |___ | |_____ |       ||   | |   |_| ||  |\n");
	printf("|  _   | |       |  |   |    |   |  |   |___ |    ___||_____  ||       ||   | |    ___||__|\n");
	printf("| |_|   ||   _   |  |   |    |   |  |       ||   |___  _____| ||   _   ||   | |   |     __ \n");
	printf("|_______||__| |__|  |___|    |___|  |_______||_______||_______||__| |__||___| |___|    |__|\n");
}

void draw_boat_art(void) {
	printf("\n\n");
	printf("                                           |__                                       \n");
	printf("                                           |\\/                                       \n");
	printf("                                           ---                                       \n");
	printf("                                           / | [                                     \n");
	printf("                                    !      | |||                                     \n");
	printf("                                  _/|     _/|-++'                                    \n");
	printf("                              +  +--|    |--|--|_ |-                                 \n");
	printf("                           { /|__|  |/\\__|  |--- |||__/                              \n");
	printf("                          +---------------___[}-_===_.'____                 /\       \n");
	printf("                      ____`-' ||___-{]_| _[}-  |     |_[___\\==--            \/   _   \n");
	printf("       __..._____--==/___]_|__|_____________________________[___\\==--____,------' .7 \n");
	printf("      \\|                                                                     BB-61/  \n");
	printf("       \\_________________________________________________________________________|   \n");

}