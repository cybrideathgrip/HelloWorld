/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5: 
                        
Date: 

Description: 

Background: 
            
Relevant Formulas: 
*/
#include "Yahtzee.h"

int main(void) {

    printf("\nWelcome! To the Game of \n");
    draw_splash_screen();
    srand(time); //seed the RNG. only needs running 1 time.

    //Mian menu has to be a loop, so we get back to it.
    //but I also want it to be a switch, so we know where to go from our menu. 
    //switch returns a 1, 2 or 3; determining what gets called next. Rules, play or exit respectively.

    int main_menu = 0;
    //outer do-while loop is our main-menu. From here we can start the game, and continue play unill we chose to exit
    do {
        //inner do-while loop checks or valid menu input.
        do {
            printf("\n\nMain Menu.\n\n");
            printf("Please Choose an entry using the corresponding number.\n");
            printf("1) Read Rules of playing Yahtzee\n");
            printf("2) Begin a game of Yahtzee!\n");
            printf("3) quit program.\n\n(An invalid choice will just reprint this menu.)\n\n");
            printf("(typing a character will break it. just input numbers please.)\n\n");
            printf("Input selection: ");
            scanf("%d", &main_menu);
            system("cls");
        } while (!(main_menu == 1 || main_menu == 2 || main_menu == 3));

        switch (main_menu){
        case 1:
            print_game_rules();
            break;
        case 2:
            game_loop();
            break;
        case 3:
            printf("Thank you for playing a game of \n");
            draw_splash_screen();
            printf("Goodbye!\n");
            break;
        }
    } while (main_menu != 3);

    printf("\nThank you so much for playing a Game of \n");
    draw_splash_screen();

    return 0;
}

