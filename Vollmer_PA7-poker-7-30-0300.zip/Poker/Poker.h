/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

#define HAND_SIZE 5

//struct declaration. before all functions so they are global

typedef struct card
{
	int face;
	int suit;
}Card;

typedef struct hand
{
	Card hand[HAND_SIZE];
}Hand;

typedef struct player {
	Hand hand;
	int points;
	int fFace[13];
	int fSuit[4];
	int draw;
	bool redraw;
}Player;

//this feels like it belongs. Much work to incorporate and validate though. Might not use.

//pretty graphcis. Reminiscent of Craps, Yahtzee and Battleship
void welcome_screen(void);
void draw_title_art(void);
void draw_card_art(void);
void print_game_rules(void);
void press_continue(void);
void draw_hand_art(void);


//shuffle cards in the alrdy initialized deck array
void shuffle(int wDeck[][13]);

//deal a hand of cards from the deck.
void deal(const int wDeck[][13], const char wFace[], const char wSuit[], /*Hand* wHand,*/ Player* player, int* wDealt, int quantity);

//print a whole hand - actually calls print_card 5x
void print_hand(Player* player, const char* wFace[], const char* wSuit[]);

//house the drawing feature. will call deal in there too.
void select_discard(Player* player);

//validate hand series
void decide_points(Player* player);
bool validate_RFlush(Player* player);
bool validate_str8_flush(Player* player);
bool validate_4kind(Player* player);
bool validate_full_house(Player* player);
bool validate_flush(Player* player);
bool validate_str8(Player* player);
//bool validate_A_str8(Player* player);
bool validate_3kind(Player* player);
bool validate_2_pair(Player* player);
bool validate_pair(Player* player);
int hi_card(Player* player);

void decide_winner(Player* player1, Player* player2);
void reset_player(Player* player);
//check number of cards
void make_freq_arrays(Player* player);
void reset_freq_arrays(Player* player);
void move_nulls_front(int arr[], int size);
void swap(int* arr, int left, int right);