/*
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date: 7/16/2020

Description: Writing a game of battleship! To be played human vs computer.
			Placing 5 boats of mostly different size on a 10x10 grid and taking turns "firing" on a coordiate to determine hit or miss once per turn.
			The victor will hit all spaces of their opponents battleships before all thier own are hit.

Background:	we'll be using a lot of strings, arrays, introducing struts, and a 'computer controlled player' for the first time.

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define GRID_SIZE 10

void welcome_screen(void);
void draw_title_art(void);
void draw_boat_art(void);

void initialize_game_board(void);

bool select_who_starts_first();
void manually_place_ships_on_board(void);
void randomly_place_ships_on_board(void);
//bool check_shot(char board, int shot[x], int shot[y]) {

int is_winner();
void update_board()

