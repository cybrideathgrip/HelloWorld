/*
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date: 7/16/2020

Description: Writing a game of battleship! To be played human vs computer.
			Placing 5 boats of mostly different size on a 10x10 grid and taking turns "firing" on a coordiate to determine hit or miss once per turn.
			The victor will hit all spaces of their opponents battleships before all thier own are hit.

Background:	we'll be using a lot of strings, arrays, introducing struts, and a 'computer controlled player' for the first time.

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <ctype.h>

#define GRID_SIZE 10
#define FLEET_SIZE 5
#define SEA_CHAR 126
#define HIT_CHAR 88
#define MISS_CHAR 48

void welcome_screen(void);
void draw_title_art(void);
void draw_boat_art(void);

void game_loop(void);
void initialize_game_board(char board[GRID_SIZE][GRID_SIZE], int rows, int cols);
void print_board(char game_board[GRID_SIZE][GRID_SIZE]);

int select_who_starts_first(void);
void place_boat(char board[][GRID_SIZE], struct boat ship,int x, int y, int horizontal);

void manually_place_ships_on_board(char board[][GRID_SIZE], struct boat ship);
void randomly_place_ships_on_board(char board[][GRID_SIZE], struct boat ship);

char rng_orientation(void);
int rng_coord(void);

//bool validate_in_bounds(boat); -> that worked...weird.
bool placement_check(char board[][GRID_SIZE], struct boat ship, int x, int y, int horizontal);
bool validate_in_bounds(struct boat ship, int x, int y, int horizontal);
bool validate_empty_space(char board[][GRID_SIZE], struct boat ship, int x, int y, int horizontal);
char check_coord(char board[][GRID_SIZE], int shot_x, int shot_y);
//void get_coords(int* x, int* y);

void player_take_turn(char target_board[][GRID_SIZE], char opponent_board[][GRID_SIZE], struct boat opponent_fleet[FLEET_SIZE], int player_points);
void cpu_take_turn(char target_board[][GRID_SIZE], char opponent_board[][GRID_SIZE], struct boat opponent_fleet[FLEET_SIZE], int player_points);
void update_opponent_fleet(char result, struct boat fleet[], int player_points);

void output_current_move(FILE* outfile);
bool check_if_sunk_ship(struct boat fleet[], int player_points);
void output_stats();

int is_winner();
void update_board(char board[][GRID_SIZE], char x, char y, char u);
//void update_fleet(Boat fleet[], char result);

void press_continue(void);
void print_game_rules(void);
void output_stats(void);

int get_x_coord(void);
int get_y_coord(void);
char get_horizontal(void);

int sequential_search(char list[], int size, char target, int* target_index_ptr);

typedef struct boat {
	char name[11];
	char symbol;
	int x_coord;
	int y_coord;
	int size;
	int hits;
	bool sunk;
}Boat;

//typedef struct ocean {
//	int 
//
//}Ocean;