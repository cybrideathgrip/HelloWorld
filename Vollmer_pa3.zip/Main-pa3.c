/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 4:  Statistical Analysis of Student Records
                        
Date: 6/24/2020

Description: This program is designed to process numbers, corresonding to student records, 
             read in from an input file. The program will evaluate some statistical calculations,
             and output the results to an output file.

Background: This Program will utilize a 4-file format for a C program, which is designed to include:
            - Conditional statements.
            - Cmpound condition.
            - Boolean expressions.
            - Custom defined functions.
            - File input & output.
            A modicum of statistical math is required for some of these equations. Most of which are provided
            

Relevant Formulas: mean = (sum of parts) / (number of parts)
                   deviation = number - mean
                   variance: is an average of the square of deviations. expressed as: variance = ((deviation_1^2)+...(deviation_N^2)) / N
                   standard deviation: the square root of the square of deviations (aka variance).
                   Some fundamentals principles of: Maximum, Minimum, Sum, and Average and square root will not be described elsewhere.
*/

#include "Header.h"

int main(void) {

    //open input.dat for reading
    FILE* input_file = NULL;
    input_file = fopen("input.dat", "r");
    
    //open output.dat for writing
    FILE* output_file = NULL;
    output_file = fopen("output.dat", "w");

    //read five records from the input file:

    //the following blocks will, in order:
    //1. initialize 5 variables for 1 student's worth of records
    //2. use the written functions read_integer() and read_double() to read in respective values
    //3. print a summary of 1 student recrod. 
    //4. then repeat in further blocks for record 2, record 3, record 4 and record 5.

    //record 1
    int student_ID_1 = 0, class_standing_1 = 0;
    double GPA_1 = 0.0, Age_1 = 0;
   // printf("fetching functions.\n\n");
    student_ID_1 = read_integer(input_file);
   // printf("student id complete. found: %d\n", student_ID_1);
    GPA_1 = read_double(input_file);
   // printf("GPA complete. found: %lf\n", GPA_1);
    class_standing_1 = read_integer(input_file);
   // printf("class standing complete. found: %d\n", class_standing_1);
    Age_1 = read_double(input_file);
   // printf("age complete. found: %lf\n", Age_1);



    printf("Found for student 1:\n\
            Student #: %8d\n\
            GPA : %lf\n\
            Class #: %d\n\
            Age : %lf\n\n",student_ID_1, GPA_1, class_standing_1, Age_1);

    //record 2 - initialize variables, set variables as input from file, print the variables for sanity
    int student_ID_2 = 0, class_standing_2 = 0;
    double GPA_2 = 0.0, Age_2 = 0;

    student_ID_2 = read_integer(input_file);
    GPA_2 = read_double(input_file);
    class_standing_2 = read_integer(input_file);
    Age_2 = read_double(input_file);

    printf("Found for student 2:\n\
            Student #: %8d\n\
            GPA : %lf\n\
            Class #: %d\n\
            Age : %lf\n\n", student_ID_2, GPA_2, class_standing_2, Age_2);


    //record 3 - initialize variables, set variables as input from file, print the variables for sanity
    int student_ID_3 = 0, class_standing_3 = 0;
    double GPA_3 = 0.0, Age_3 = 0;

    student_ID_3 = read_integer(input_file);
    GPA_3 = read_double(input_file);
    class_standing_3 = read_integer(input_file);
    Age_3 = read_double(input_file);

    printf("Found for student 3:\n\
            Student #: %8d\n\
            GPA : %lf\n\
            Class #: %d\n\
            Age : %lf\n\n", student_ID_3, GPA_3, class_standing_3, Age_3);

    //record 4 - initialize variables, set variables as input from file, print the variables for sanity
    int student_ID_4 = 0, class_standing_4 = 0;
    double GPA_4 = 0.0, Age_4 = 0;

    student_ID_4 = read_integer(input_file);
    GPA_4 = read_double(input_file);
    class_standing_4 = read_integer(input_file);
    Age_4 = read_double(input_file);

    printf("Found for student 4:\n\
            Student #: %8d\n\
            GPA : %lf\n\
            Class #: %d\n\
            Age : %lf\n\n", student_ID_4, GPA_4, class_standing_4, Age_4);

    //record 5 - initialize variables, set variables as input from file, print the variables for sanity
    int student_ID_5 = 0, class_standing_5 = 0;
    double GPA_5 = 0.0, Age_5 = 0;

    student_ID_5 = read_integer(input_file);
    GPA_5 = read_double(input_file);
    class_standing_5 = read_integer(input_file);
    Age_5 = read_double(input_file);

    printf("Found for student 5:\n\
            Student #: %8d\n\
            GPA : %lf\n\
            Class #: %d\n\
            Age : %lf\n\n", student_ID_5, GPA_5, class_standing_5, Age_5);

    //Calculate the sum of the GPAs
    double gpa_sum = 0.0;
    gpa_sum = calculate_sum(GPA_1, GPA_2, GPA_3, GPA_4, GPA_5);
    printf("\n sum of GPAs is: %lf", gpa_sum); //checks out

    //Calculate the sum of the class standing
    double sum_class_standings = 0.0;
    sum_class_standings = calculate_sum(class_standing_1, class_standing_2, class_standing_3, class_standing_4, class_standing_5);
    printf("\n sum of class standings: %d", (int)sum_class_standings);

    //Calculate the sum of the ages
    double sum_of_the_ages = 0;
    sum_of_the_ages = calculate_sum(Age_1, Age_2, Age_3, Age_4, Age_5); //unecessary variable name? yeah probobly. But it was described in the assignemnt as such. Besides, it has a nice, mythical ring to it ;)
    printf("\n sum of the Ages : %lf", sum_of_the_ages);

    //Calculate the mean of the GPAs -> write result to output file
    double mean_gpa = 0.0;
    mean_gpa = calculate_mean(gpa_sum, 5);
    printf("\n\nAverage GPA looks like: %lf", mean_gpa);
    print_double(output_file, mean_gpa);

    //Calculate the mean of the class standings -> write result to output file
    double mean_class_standing = 0.0;
    mean_class_standing = calculate_mean(sum_class_standings, 5);
    printf("\nMean Class Standing is: %lf", mean_class_standing);
    print_double(output_file, mean_class_standing);

    //Calculate the mean of the ages  -> write result to output file
    double mean_of_the_ages = 0.0;
    mean_of_the_ages = calculate_mean(sum_of_the_ages, 5);
    printf("\nAverage Age is: %lf\n", mean_of_the_ages);
    print_double(output_file, mean_of_the_ages);
    
    //Calculate the deviation of each GPA: need to call calculate_deviation() 5 times...
    double gpa_deviation_1 = 0.2, gpa_deviation_2 = 0.0, gpa_deviation_3 = 0.0, gpa_deviation_4 = 0.0, gpa_deviation_5 = 0.0;

    gpa_deviation_1 = calculate_deviation(GPA_1, mean_gpa);
    gpa_deviation_2 = calculate_deviation(GPA_2, mean_gpa);
    gpa_deviation_3 = calculate_deviation(GPA_3, mean_gpa);
    gpa_deviation_4 = calculate_deviation(GPA_4, mean_gpa);
    gpa_deviation_5 = calculate_deviation(GPA_5, mean_gpa);

    printf("\nDeviation of gpa from mean: GPA1 %lf - mean %lf= deviation1 %lf", GPA_1, mean_gpa, gpa_deviation_1);
    printf("\nDeviation of gpa from mean: GPA2 %lf - mean %lf= deviation2 %lf", GPA_2, mean_gpa, gpa_deviation_2);
    printf("\nDeviation of gpa from mean: GPA3 %lf - mean %lf= deviation3 %lf", GPA_3, mean_gpa, gpa_deviation_3);
    printf("\nDeviation of gpa from mean: GPA4 %lf - mean %lf= deviation4 %lf", GPA_4, mean_gpa, gpa_deviation_4);
    printf("\nDeviation of gpa from mean: GPA5 %lf - mean %lf= deviation5 %lf", GPA_5, mean_gpa, gpa_deviation_5);

    //calculate the variance of the GPAs
    double gpa_variance = 0.0;
    gpa_variance = calculate_variance(gpa_deviation_1, gpa_deviation_2, gpa_deviation_3, gpa_deviation_4, gpa_deviation_5, 5);
    printf("\n\nvariance of gpas: %lf", gpa_variance);
    
    //calculate the standard deviation of all the GPAs -> write result to output file
    double gpa_standard_deviation = 0.0;
    gpa_standard_deviation = calculate_standard_deviation(gpa_variance);
    printf("\nGPA standard deviation: %lf", gpa_standard_deviation);
    print_double(output_file, gpa_standard_deviation);

    //Determine the minimum of the GPAs -> write result to output file
    double gpa_minimum = 0.0;
    gpa_minimum = find_min(GPA_1, GPA_2, GPA_3, GPA_4, GPA_5);
    printf("\nLowest GPA: %lf", gpa_minimum);
    print_double(output_file, gpa_minimum);

    //Determine the maximum of the GPAs -> write result to output file
    double gpa_maximum = 0.0;
    gpa_maximum = find_max(GPA_1, GPA_2, GPA_3, GPA_4, GPA_5);
    printf("\nLowest GPA: %lf", gpa_maximum);
    print_double(output_file, gpa_maximum);

    //Close the input and output files.
    fclose(input_file);
    fclose(output_file);

    return 0;
}