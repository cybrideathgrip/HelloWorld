

#include "Header.h"

//function reads one double-precision number from a file
double read_double(FILE* infile){
	double r = 0.0;
	fscanf(infile, " %lf", &r);
	return r;
}

//function reads one integer number from a file
int read_integer(FILE* infile){
	int r = 0;
	fscanf(infile, " %d", &r);
	return r;
}

//function returns the sum of five double-numbers passed to it
double calculate_sum(double number1, \
					 double number2, \
					 double number3, \
					 double number4, \
					 double number5){
	double sum = 0.0;
	sum = number1 + number2 + number3 + number4 + number5;
	return sum;
}

//function calcuates a mean from a sum and number passed into the function call.
//caveat: The function only works if number is not zero. (we are assuming Number will not be negative.
//if number is zero, then -1.0 is returned.
double calculate_mean(double sum, int number){
	double mean = 0.0;
	if(number != 0)
	{
		mean = sum / number;
		return mean;
	}
	else
	{
		printf("ERROR! Cannot Divide by Zero. Check the 'Number' variable passed to function: claculate_mean()\n");
		return -1.0;
	}
}

//function double calculate_variance double
double calculate_deviation(double number, double mean){
	double deviation = 0.0;
	deviation = number - mean;
	return deviation;
}

//function to calculate variance of 5 numbers. Also calls the calculate mean for an intermediary sum.
double calculate_variance(double deviation1, \
						  double deviation2, \
						  double deviation3, \
						  double deviation4, \
						  double deviation5, \
						  int number){
	double variance = 0.0;
	double variance_sum = 0.0;
	variance_sum = (pow(deviation1, 2) + pow(deviation2, 2) + pow(deviation3, 2) + pow(deviation4, 2) + pow(deviation5, 2));
	variance = calculate_mean(variance_sum, number);
	return variance;
}

//function to calculate standard deviation of the variance. Invokes the sqrt() function from the math.h library.
double calculate_standard_deviation(double variance){
	double std_dev = 0.0;
	std_dev = sqrt(variance);
	return std_dev;
}

//funciton determines maximum of 5 values passed to it
double find_max(double number1, \
				double number2, \
				double number3, \
				double number4, \
				double number5){

	double cur_max = number1;
	if (cur_max < number2)
	{
		cur_max = number2;
	}
	if (cur_max < number3) 
	{
		cur_max = number3;
	}
	if (cur_max < number4) 
	{
		cur_max = number4;
	}
	if (cur_max < number5) 
	{
		cur_max = number5;
	}
	
	return cur_max;
}

//funciton determines minimum of 5 values passed to it
double find_min(double number1, \
	double number2, \
	double number3, \
	double number4, \
	double number5){

	double cur_min = number1;

	if (cur_min > number2)
	{
		cur_min = number2;
	}
	if (cur_min > number3)
	{
		cur_min = number3;
	}
	if (cur_min > number4)
	{
		cur_min = number4;
	}
	if (cur_min > number5)
	{
		cur_min = number5;
	}

	return cur_min;
}

//funciton prints a single precision value to 2 decimal places, out to a file 
void print_double(FILE* outfile, double number){
	fprintf(outfile, "%.2lf\n", number);
}
