/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5: 
                        
Date: 

Description: 

Background: 
            
Relevant Formulas: 
*/
#include "Poker.h"

int main(void)
{
	/* initialize suit array */
	const char* suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };

	/* initialize face array */
	const char* face[13] = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen", "King" };

	/* initalize deck array -in memory! */
	int deck[4][13] = { 0 };
    int dealt_count = 0; //tracks how many cards have been dealt.

    /*initialize a hand to populate with cards */
    Hand p1_hand = { 0 };
    Hand p2_hand = { 0 };
    
	srand((unsigned)time(NULL));  /* seed random-number generator */
	shuffle(&deck);
    //deal(deck, face, suit, &p1_hand, &dealt_count, 5);
    //deal(deck, face, suit, &p1_hand, &dealt_count, 2);
 
    printf("Welcome! To the Game of...\n\n");
    welcome_screen();

    //===============================================================================================|
    //Main menu has to be a loop, so we get back to it.                                              |
    //but I also want it to be a switch, so we know where to go from our menu.                       |
    //switch returns a 1, 2 or 3; determins what gets called next. Rules, play or exit respectively. |
    //===============================================================================================|
    
    int main_menu = 0;
    char cont = '\0';
    int card = NULL;
    system("cls");
    //outer do-while loop is our main-menu. From here we can start the game, and continue play unill we chose to exit
    do {
        //inner do-while loop checks for valid menu input.
        do {
            printf("\n\nMain Menu.\n");
            printf("------------------\n");
            printf("Please Choose an entry using the corresponding number.\n\n");
            printf("1) Read Rules of Poker.\n\n");
            printf("2) Begin a game of Poker!\n\n");
            printf("3) quit program.\n\n(An invalid choice will just reprint this menu.)\n\n");
            printf("(typing a character may crash it. just input numbers please.)\n\n");
            printf("Input selection: ");
            scanf("%d", &main_menu);
            //system("cls");
        } while (!(main_menu == 1 || main_menu == 2 || main_menu == 3));

        switch (main_menu) {
        case 1:
            print_game_rules();
            break;
        case 2:
           //game_loop(); while(continue == 'y' || contineu == 'Y'){
        
                //deck initialized and shuffled outside loop.
            //begin play loop.
                //ante up p1, p2. pot += p1-bet ; pot += p2-bet.

                //deal hand for p1. 
            deal(deck, face, suit, &p1_hand, &dealt_count, 5);
            
            //print_hand(&p1_hand, face, suit);
            print_card(&p1_hand.hand[1], face, suit);


                //deal hand for p2.
            deal(deck, face, suit, &p2_hand, &dealt_count, 5);
                //bet, check, fold p1, 
                //bet, check, fold p2,

                //draw N cards p1
                //draw N card p2

                //bet, check, fold p1, 
                //bet, check, fold p2,
            
                //compare hands p1 p2.

                //decide winner
            //play again or exit.

            //deal_hand(deck, face, suit, &p1_hand);

           /* for (int i = 0; i < HAND_SIZE; i++)
            {
                deal_a_card(deck, face, suit, &p1_hand.hand[i]);
                print_card(p1_hand.hand[i], face, suit);
            }*/
            
            //deal(deck, face, suit, &p1_hand, &dealt_count, 5);
            //print_hand(p1_hand, face, suit);


           /* deal_a_card(deck, face, suit, &p1_hand.hand[0]);
            print_card(p1_hand.hand[0], face, suit);*/
            

            break;
        case 3:
            printf("Thank you for playing a game of \n");
            welcome_screen();
            printf("Goodbye!\n");
            break;
        }
    } while (main_menu != 3);

    printf("\nThank you so much for playing a Game of...\n\n");
    welcome_screen();

	return 0;
}