/* 
Programmer: Simon Vollmer
Class: CptS 121, Lab Section 01
Instructor: Andrew O'Fallon
Programming Assignment 5:

Date:

Description:

Background:

Relevant Formulas:
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <stdbool.h>

#define HAND_SIZE 5

// 5 functions for drawing & printing 
void draw_splash_screen(void); //calls draw draw_title_art, and draw_dice_art for the title.
void print_game_rules(void); 
void draw_dice_art(void);
void draw_title_art(void);
void draw_splash_screen(void);

void press_continue(void); //this will be used a lot in between functions, actions & choices.

int game_loop(void); //main game loop. Will end when a player has won, return 1 for player 1, 2 for player 2. 
	//int player loop - roll & reroll loop for a player. If player 2/1 respectively  if count is even/odd

int roll_die(void); //return the roll of 1 die. Where to put it is not it's job
void roll_hand(int* hand[], int hand_size, bool* hold[]); //put the resultant die rolls into a 'hand' of 5 dice.
void draw_roll(int number);
void draw_hand(int* hand[], int hand_size);

bool save_hand();
void update_hold(bool* hold[]);
void reset_hold(bool* hold[], int size);

int save_points(int* hand[], int size, int point_rack_);
int check_points(int* hand[], int size); // when it's time to check rolls, I want this function to call all the other check or validate functions...maybe.

void print_point_menu(void);

int validate_sum_of_Ns(int* hand[], int size, int N); //maybe want to break that out
int validate_Full_House(int* hand[],int size);
int validate_3_kind(int* hand[], int size);
int validate_4_kind(int* hand[], int size);
int validate_small_straight(int* hand[], int size);
int validate_large_straight(int* hand[], int size);
int validate_yahtzee(int* hand[], int size);
int validate_chance(int* hand[], int size);